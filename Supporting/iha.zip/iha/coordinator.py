"""Coordinator for IHA."""

from __future__ import annotations

import asyncio
from copy import deepcopy
from datetime import timedelta
import logging
import time
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import IhaApi, IhaApiError
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

POLL_SECONDS = 10
STALE_STATUS_SECONDS = 600
ERROR_LOG_SECONDS = 60


def _mode_from_ha(value: object) -> str:
    text = str(value or "").strip().lower()
    if text.startswith("hvacmode."):
        text = text.split(".", 1)[1]
    if text in {"heat_cool", "auto"}:
        return "auto"
    if text in {"off", "heat", "cool"}:
        return text
    return ""


def _ha_from_mode(mode: str) -> str:
    return "heat_cool" if mode == "auto" else mode


def _boolish(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value or "").strip().lower()
    return text in {"1", "true", "yes", "on", "enabled", "away"}


TARGET_TEMPERATURE_KEYS = (
    "target_temperature",
    "temperature",
    "targetTemp",
    "targetTemperature",
    "target_temp_high",
    "targetTemperatureHigh",
    "target_temp_low",
    "targetTemperatureLow",
)


def _payload_has_target_temperature(payload: dict[str, Any] | None) -> bool:
    return isinstance(payload, dict) and any(key in payload for key in TARGET_TEMPERATURE_KEYS)


def _payload_target_temperature(payload: dict[str, Any] | None, current_mode: object | None = None) -> Any | None:
    if not isinstance(payload, dict):
        return None
    for key in ("target_temperature", "temperature", "targetTemp", "targetTemperature"):
        if key in payload:
            return payload[key]

    high = payload.get("target_temp_high", payload.get("targetTemperatureHigh"))
    low = payload.get("target_temp_low", payload.get("targetTemperatureLow"))
    requested_mode = _mode_from_ha(payload.get("hvac_mode", payload.get("hvacMode", payload.get("mode", current_mode or ""))))

    if requested_mode == "cool" and high is not None:
        return high
    if requested_mode == "heat" and low is not None:
        return low
    if high is not None and low is not None:
        try:
            return round((float(high) + float(low)) / 2)
        except (TypeError, ValueError):
            return high
    if high is not None:
        return high
    if low is not None:
        return low
    return None


def _payload_explicitly_leaves_away(payload: dict[str, Any] | None) -> bool:
    if not isinstance(payload, dict):
        return False
    if "away" in payload and not _boolish(payload.get("away")):
        return True
    preset = payload.get("preset_mode", payload.get("presetMode"))
    return str(preset or "").strip().lower() == "home"


def _data_is_away(data: dict[str, Any] | None) -> bool:
    if not isinstance(data, dict):
        return False
    climate = data.get("climate") if isinstance(data.get("climate"), dict) else data.get("thermostat")
    source = climate if isinstance(climate, dict) else data
    preset = str(source.get("preset_mode") or source.get("presetMode") or "").strip().lower()
    return _boolish(source.get("away")) or preset == "away"


def _with_home_assistant_command_source(payload: dict[str, Any] | None) -> dict[str, Any]:
    """Tag HA writes so the panel does not mistake them for stale echoes."""
    tagged = dict(payload or {})
    tagged.setdefault("commandSource", "home-assistant")
    tagged.setdefault("source", "home-assistant")

    if any(key in tagged for key in ("hvac_mode", "hvacMode", "mode")):
        tagged.setdefault("modeChangeSource", "home-assistant")
        tagged.setdefault("hvacModeChangeSource", "home-assistant")

    if any(key in tagged for key in TARGET_TEMPERATURE_KEYS):
        tagged.setdefault("targetChangeSource", "home-assistant")
        tagged.setdefault("temperatureChangeSource", "home-assistant")

    if any(key in tagged for key in ("fan_mode", "fanMode", "fan")):
        tagged.setdefault("fanChangeSource", "home-assistant")

    if any(key in tagged for key in ("preset_mode", "presetMode", "away")):
        tagged.setdefault("presetChangeSource", "home-assistant")

    return tagged


class IhaCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll and command the local thermostat."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        super().__init__(
            hass,
            logger=_LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=POLL_SECONDS),
        )
        self.api = api
        self._control_lock = asyncio.Lock()
        self._optimistic_control: dict[str, Any] = {}
        self._optimistic_until = 0.0
        self._last_success_monotonic = 0.0
        self._last_success_wall = 0.0
        self._consecutive_failures = 0
        self._last_error = ""
        self._using_cached_status = False
        self._next_error_log_at = 0.0

    @property
    def last_success_age_seconds(self) -> float | None:
        """Return the age of the last live panel response."""
        if not self._last_success_monotonic:
            return None
        return max(0.0, time.monotonic() - self._last_success_monotonic)

    @property
    def has_recent_status(self) -> bool:
        """Return True while cached panel data is still safe to show in HA."""
        age = self.last_success_age_seconds
        return bool(self.data) and age is not None and age < STALE_STATUS_SECONDS

    @property
    def connection_diagnostics(self) -> dict[str, Any]:
        """Return lightweight diagnostics for the HA entity attributes."""
        age = self.last_success_age_seconds
        return {
            "poll_seconds": POLL_SECONDS,
            "stale_status_seconds": STALE_STATUS_SECONDS,
            "last_success_at": int(self._last_success_wall) if self._last_success_wall else None,
            "last_success_age_seconds": round(age, 1) if age is not None else None,
            "consecutive_failures": self._consecutive_failures,
            "last_error": self._last_error or None,
            "using_cached_status": self._using_cached_status,
            "entity_available_from_cache": self.has_recent_status,
        }

    def _apply_optimistic_control(self, data: dict[str, Any] | None, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        """Keep HA from flashing stale values while a panel command settles."""
        base = deepcopy(data) if isinstance(data, dict) else {}
        patch = payload if isinstance(payload, dict) else self._optimistic_control
        if not isinstance(patch, dict) or not patch:
            return base

        climate = base.get("climate") if isinstance(base.get("climate"), dict) else None
        if climate is None:
            climate = base.get("thermostat") if isinstance(base.get("thermostat"), dict) else {}
        if not isinstance(climate, dict):
            climate = {}

        def put(key: str, value: Any) -> None:
            base[key] = value
            climate[key] = value

        if "hvac_mode" in patch or "hvacMode" in patch or "mode" in patch:
            requested = patch.get("hvac_mode", patch.get("hvacMode", patch.get("mode")))
            mode = _mode_from_ha(requested)
            if mode:
                put("mode", mode)
                put("hvac_mode", _ha_from_mode(mode))
                put("hvacMode", _ha_from_mode(mode))

        if _payload_has_target_temperature(patch):
            if not (_data_is_away(base) and not _payload_explicitly_leaves_away(patch)):
                temp = _payload_target_temperature(patch, climate.get("mode") or climate.get("hvac_mode"))
                put("target_temperature", temp)
                put("temperature", temp)
                put("targetTemp", temp)

        if "fan_mode" in patch or "fanMode" in patch or "fan" in patch:
            fan = str(patch.get("fan_mode", patch.get("fanMode", patch.get("fan", "auto"))) or "auto")
            put("fan_mode", fan)
            put("fanMode", fan)
            put("fan", fan)

        if "preset_mode" in patch or "presetMode" in patch or "away" in patch:
            preset = str(patch.get("preset_mode", patch.get("presetMode", "away" if patch.get("away") else "home")) or "home").lower()
            away = preset == "away" or bool(patch.get("away"))
            put("away", away)
            put("preset_mode", "away" if away else "home")
            put("presetMode", "away" if away else "home")

        base["climate"] = climate
        base["thermostat"] = climate
        return base

    def _note_success(self) -> None:
        now = time.monotonic()
        self._last_success_monotonic = now
        self._last_success_wall = time.time()
        self._consecutive_failures = 0
        self._last_error = ""
        self._using_cached_status = False

    def _cached_status_or_raise(self, exc: Exception) -> dict[str, Any]:
        self._consecutive_failures += 1
        self._last_error = str(exc)
        age = time.monotonic() - self._last_success_monotonic if self._last_success_monotonic else None

        if self.data and age is not None and age < STALE_STATUS_SECONDS:
            self._using_cached_status = True
            cached = deepcopy(self.data)
            cached["ok"] = True
            cached["ihaApiStatusSource"] = "cached"
            cached["ihaApiLastError"] = self._last_error
            cached["ihaApiConsecutiveFailures"] = self._consecutive_failures
            cached["ihaApiLastSuccessAgeSeconds"] = round(age, 1)
            now = time.monotonic()
            if now >= self._next_error_log_at:
                _LOGGER.warning(
                    "IHA thermostat status poll failed; keeping last known state for %.1f more seconds. Error: %s",
                    max(0.0, STALE_STATUS_SECONDS - age),
                    exc,
                )
                self._next_error_log_at = now + ERROR_LOG_SECONDS
            return cached

        self._using_cached_status = False
        raise UpdateFailed(str(exc)) from exc

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.status()
        except IhaApiError as exc:
            return self._cached_status_or_raise(exc)

        self._note_success()
        if self._optimistic_control and time.monotonic() < self._optimistic_until:
            return self._apply_optimistic_control(data)
        self._optimistic_control = {}
        self._optimistic_until = 0.0
        return data

    async def async_control(self, payload: dict[str, Any]) -> None:
        async with self._control_lock:
            payload = _with_home_assistant_command_source(payload)
            if (
                _payload_has_target_temperature(payload)
                and _data_is_away(self.data)
                and not _payload_explicitly_leaves_away(payload)
            ):
                _LOGGER.info("Ignoring Home Assistant target temperature command because IHA Away mode is active")
                self._optimistic_control = {}
                self._optimistic_until = 0.0
                if self.data:
                    self.async_set_updated_data(deepcopy(self.data))
                return

            self._optimistic_control = dict(payload or {})
            self._optimistic_until = time.monotonic() + 5.0
            if self.data:
                self.async_set_updated_data(self._apply_optimistic_control(self.data, payload))
            try:
                data = await self.api.control(payload)
            except Exception:
                self._optimistic_control = {}
                self._optimistic_until = 0.0
                raise
            self._note_success()
            # The wall panel normally returns the accepted state immediately, but
            # hold the requested command briefly so HA's next poll cannot
            # momentarily flash the old mode/target if it races with the control
            # loop or a slow Wi-Fi round trip.
            self._optimistic_until = time.monotonic() + 2.5
            self.async_set_updated_data(self._apply_optimistic_control(data, payload))
