"""Data coordinators for the IHA integration."""

from __future__ import annotations

from datetime import timedelta
import logging
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import IhaApi, IhaApiError

_LOGGER = logging.getLogger(__name__)


class IhaCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll the primary thermostat status endpoint."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        self.hardware_coordinator: IhaHardwareCoordinator | None = None
        self.update_coordinator: IhaUpdateCoordinator | None = None
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} thermostat",
            update_interval=timedelta(seconds=10),
            always_update=True,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            return await self.api.status()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc


class IhaHardwareCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll independent motion and onboard sensor telemetry."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} hardware",
            update_interval=timedelta(seconds=3),
            always_update=True,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.hardware_telemetry()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        config = motion.get("config") if isinstance(motion.get("config"), dict) else {}
        try:
            seconds = int(config.get("pollSeconds") or 3)
        except (TypeError, ValueError):
            seconds = 3
        self.update_interval = timedelta(seconds=max(1, min(30, seconds)))
        return data


class IhaUpdateCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll software availability separately from climate state."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} software",
            update_interval=timedelta(minutes=15),
            always_update=True,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.update_status()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        self.update_interval = timedelta(seconds=5) if data.get("inProgress") else timedelta(minutes=15)
        return data

    def set_fallback_data(self, data: dict[str, Any]) -> None:
        """Seed usable software data if the first dedicated poll fails."""
        self.async_set_updated_data(data)

    async def async_force_refresh_remote(self) -> None:
        """Force the panel to re-check the configured Git branch."""
        try:
            data = await self.api.update_status(refresh=True)
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        self.async_set_updated_data(data)
