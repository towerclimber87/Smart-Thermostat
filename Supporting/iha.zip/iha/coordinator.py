"""Data coordinators for the IHA integration."""

from __future__ import annotations

import asyncio
from copy import deepcopy
from datetime import timedelta
import logging
from time import monotonic
from typing import Any
from uuid import uuid4

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import IhaApi, IhaApiError

_LOGGER = logging.getLogger(__name__)
_COMMAND_HOLD_SECONDS = 20.0


def _climate_data(data: object) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    nested = data.get("climate") or data.get("thermostat")
    return nested if isinstance(nested, dict) else data


def _first(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in data:
            return data.get(key)
    return None


def _number(data: dict[str, Any], *keys: str) -> float | None:
    value = _first(data, *keys)
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _integer(data: dict[str, Any], *keys: str) -> int | None:
    value = _number(data, *keys)
    return int(value) if value is not None else None


def _overlay_climate_values(data: object, updates: dict[str, Any]) -> dict[str, Any]:
    """Copy a status payload and update all duplicate climate representations."""
    result = deepcopy(data) if isinstance(data, dict) else {}
    mappings: list[dict[str, Any]] = [result]
    for key in ("climate", "thermostat"):
        nested = result.get(key)
        if isinstance(nested, dict):
            mappings.append(nested)

    for mapping in mappings:
        if "target" in updates:
            target = float(updates["target"])
            mapping["targetTemp"] = target
            mapping["target_temperature"] = target
            mapping["temperature"] = target
        if "target_revision" in updates and updates["target_revision"] is not None:
            mapping["targetRevision"] = int(updates["target_revision"])
        if "mode" in updates:
            mode = str(updates["mode"])
            mapping["mode"] = mode
            mapping["hvac_mode"] = mode
            mapping["hvacMode"] = mode
        if "mode_revision" in updates and updates["mode_revision"] is not None:
            mapping["modeRevision"] = int(updates["mode_revision"])
    return result


class IhaCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll the primary thermostat status endpoint and serialize control writes."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        self.hardware_coordinator: IhaHardwareCoordinator | None = None
        self.update_coordinator: IhaUpdateCoordinator | None = None
        self._control_lock = asyncio.Lock()
        self._client_session_id = uuid4().hex
        self._client_command_sequence = 0
        self._target_hold: tuple[float, int | None, float] | None = None
        self._mode_hold: tuple[str, int | None, float] | None = None
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} thermostat",
            update_interval=timedelta(seconds=10),
            always_update=True,
        )

    def _apply_command_holds(self, data: dict[str, Any]) -> dict[str, Any]:
        """Prevent an older in-flight poll from repainting a confirmed command."""
        climate = _climate_data(data)
        now = monotonic()
        updates: dict[str, Any] = {}

        if self._target_hold is not None:
            target, revision, expires = self._target_hold
            live_target = _number(climate, "target_temperature", "temperature", "targetTemp")
            live_revision = _integer(climate, "targetRevision")
            confirmed = live_target is not None and abs(live_target - target) < 0.01 and (
                revision is None or live_revision is None or live_revision >= revision
            )
            superseded = revision is not None and live_revision is not None and live_revision > revision
            if confirmed or superseded or now >= expires:
                self._target_hold = None
            else:
                updates["target"] = target
                updates["target_revision"] = revision

        if self._mode_hold is not None:
            mode, revision, expires = self._mode_hold
            live_mode = str(_first(climate, "hvac_mode", "hvacMode", "mode") or "").lower()
            live_revision = _integer(climate, "modeRevision")
            confirmed = live_mode == mode and (
                revision is None or live_revision is None or live_revision >= revision
            )
            superseded = revision is not None and live_revision is not None and live_revision > revision
            if confirmed or superseded or now >= expires:
                self._mode_hold = None
            else:
                updates["mode"] = mode
                updates["mode_revision"] = revision

        return _overlay_climate_values(data, updates) if updates else data

    def _publish_optimistic(self, updates: dict[str, Any]) -> None:
        if self.data is None:
            return
        self.async_set_updated_data(_overlay_climate_values(self.data, updates))

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.status()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        return self._apply_command_holds(data)

    async def async_control(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Send one ordered command using the last panel state as its base."""
        async with self._control_lock:
            command = dict(payload)
            current = _climate_data(self.data or {})
            self._client_command_sequence += 1
            command["clientCommandId"] = f"{self._client_session_id}:{self._client_command_sequence}"

            requested_target = _number(command, "targetTemp", "target_temperature", "temperature")
            requested_mode_raw = _first(command, "mode", "hvac_mode", "hvacMode")
            requested_mode = str(requested_mode_raw).lower() if requested_mode_raw is not None else ""

            if requested_target is not None:
                current_revision = _integer(current, "targetRevision")
                current_target = _number(current, "target_temperature", "temperature", "targetTemp")
                if current_revision is not None:
                    command["expectedTargetRevision"] = current_revision
                if current_target is not None:
                    command["expectedTargetTemp"] = current_target
                optimistic_revision = current_revision + 1 if current_revision is not None else None
                self._target_hold = (requested_target, optimistic_revision, monotonic() + _COMMAND_HOLD_SECONDS)
                self._publish_optimistic({"target": requested_target, "target_revision": optimistic_revision})

            if requested_mode in {"off", "heat", "cool", "auto"}:
                current_revision = _integer(current, "modeRevision")
                current_mode = str(_first(current, "hvac_mode", "hvacMode", "mode") or "").lower()
                if current_revision is not None:
                    command["expectedModeRevision"] = current_revision
                if current_mode:
                    command["expectedMode"] = current_mode
                optimistic_revision = current_revision + 1 if current_revision is not None else None
                self._mode_hold = (requested_mode, optimistic_revision, monotonic() + _COMMAND_HOLD_SECONDS)
                self._publish_optimistic({"mode": requested_mode, "mode_revision": optimistic_revision})

            try:
                result = await self.api.control(command)
            except Exception:
                if requested_target is not None:
                    self._target_hold = None
                if requested_mode:
                    self._mode_hold = None
                raise

            command_result = result.get("commandResult") if isinstance(result.get("commandResult"), dict) else {}
            rejected_reason = str(command_result.get("reason") or "").strip()
            target_rejected = requested_target is not None and command_result.get("targetAccepted") is False
            mode_rejected = bool(requested_mode) and command_result.get("modeAccepted") is False
            if target_rejected:
                self._target_hold = None
            if mode_rejected:
                self._mode_hold = None
            if target_rejected or mode_rejected:
                self.async_set_updated_data(result)
                raise IhaApiError(rejected_reason or "The panel changed before this Home Assistant command arrived.")

            confirmed = _climate_data(result)
            if requested_target is not None:
                revision = _integer(confirmed, "targetRevision")
                self._target_hold = (requested_target, revision, monotonic() + _COMMAND_HOLD_SECONDS)
            if requested_mode:
                revision = _integer(confirmed, "modeRevision")
                normalized_mode = str(_first(confirmed, "hvac_mode", "hvacMode", "mode") or requested_mode).lower()
                self._mode_hold = (normalized_mode, revision, monotonic() + _COMMAND_HOLD_SECONDS)

            # Publish the accepted control response without consuming the hold.
            # The next ordinary GET must confirm it; any older GET that was already
            # in flight will carry a lower revision and be overlaid instead.
            updates: dict[str, Any] = {}
            if requested_target is not None:
                updates["target"] = requested_target
                updates["target_revision"] = _integer(confirmed, "targetRevision")
            if requested_mode:
                updates["mode"] = str(_first(confirmed, "hvac_mode", "hvacMode", "mode") or requested_mode).lower()
                updates["mode_revision"] = _integer(confirmed, "modeRevision")
            result = _overlay_climate_values(result, updates) if updates else result
            self.async_set_updated_data(result)
            return result

    async def async_run_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Run a saved panel schedule and protect its confirmed target from stale polls."""
        async with self._control_lock:
            result = await self.api.run_schedule(schedule_id)
            confirmed = _climate_data(result)
            target = _number(confirmed, "target_temperature", "temperature", "targetTemp")
            if target is not None:
                revision = _integer(confirmed, "targetRevision")
                self._target_hold = (target, revision, monotonic() + _COMMAND_HOLD_SECONDS)
            self.async_set_updated_data(result)
            return result

    @property
    def command_pending(self) -> bool:
        return self._target_hold is not None or self._mode_hold is not None


class IhaHardwareCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll independent motion and onboard sensor telemetry."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} hardware",
            update_interval=timedelta(seconds=3),
            always_update=True,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.hardware_telemetry()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        config = motion.get("config") if isinstance(motion.get("config"), dict) else {}
        try:
            seconds = int(config.get("pollSeconds") or 3)
        except (TypeError, ValueError):
            seconds = 3
        self.update_interval = timedelta(seconds=max(1, min(30, seconds)))
        return data


class IhaUpdateCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Poll software availability separately from climate state."""

    def __init__(self, hass: HomeAssistant, api: IhaApi) -> None:
        self.api = api
        super().__init__(
            hass,
            _LOGGER,
            name=f"IHA {api.host} software",
            update_interval=timedelta(minutes=15),
            always_update=True,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            data = await self.api.update_status()
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        self.update_interval = timedelta(seconds=5) if data.get("inProgress") else timedelta(minutes=15)
        return data

    def set_fallback_data(self, data: dict[str, Any]) -> None:
        """Seed usable software data if the first dedicated poll fails."""
        self.async_set_updated_data(data)

    async def async_force_refresh_remote(self) -> None:
        """Force the panel to re-check the configured Git branch."""
        try:
            data = await self.api.update_status(refresh=True)
        except IhaApiError as exc:
            raise UpdateFailed(str(exc)) from exc
        self.async_set_updated_data(data)
