"""Lock platform for the IHA thermostat screen."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from homeassistant.components.lock import LockEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaCoordinatorEntity, panel_serial


def _lock_data(data: object) -> dict[str, Any]:
    """Find screen-lock state in either the modern or compatibility payload."""
    if not isinstance(data, dict):
        return {}
    value = data.get("screenLock", data.get("screen_lock"))
    if isinstance(value, dict):
        return value
    for key in ("climate", "thermostat"):
        nested = data.get(key)
        if isinstance(nested, dict):
            value = nested.get("screenLock", nested.get("screen_lock"))
            if isinstance(value, dict):
                return value
    return {}


def _with_lock_data(data: object, screen_lock: dict[str, Any]) -> dict[str, Any]:
    """Overlay screen-lock state into all status payload representations."""
    current = deepcopy(data) if isinstance(data, dict) else {}
    current["screenLock"] = deepcopy(screen_lock)
    current["screen_lock"] = deepcopy(screen_lock)
    for key in ("climate", "thermostat"):
        nested = current.get(key)
        if isinstance(nested, dict):
            nested["screenLock"] = deepcopy(screen_lock)
            nested["screen_lock"] = deepcopy(screen_lock)
    return current


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    parent: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    # The screen lock is a primary thermostat control, not a hardware sensor.
    # Always create it whenever the IHA thermostat entry itself is available.
    async_add_entities([IhaScreenLock(entry, parent)])


class IhaScreenLock(CoordinatorEntity[IhaCoordinator], LockEntity):
    """Control the normal tap/guest screen lock from Home Assistant."""

    _attr_has_entity_name = True
    _attr_name = "Screen Lock"
    _attr_icon = "mdi:tablet-lock"

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = coordinator
        self._serial = panel_serial(entry, coordinator)
        self._attr_unique_id = f"{self._serial}_screen_lock"

    def _data(self) -> dict[str, Any]:
        return _lock_data(self.coordinator.data)

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

    @property
    def is_locked(self) -> bool:
        return bool(self._data().get("locked"))

    @property
    def available(self) -> bool:
        return bool(self.coordinator.last_update_success and self._data())

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        lock = self._data()
        return {
            "lock_mode": lock.get("mode"),
            "security_locked": bool(lock.get("securityLocked", lock.get("security_locked", False))),
            "updated_at": lock.get("updatedAt", lock.get("updated_at")),
        }

    async def _async_set_locked(self, locked: bool) -> None:
        try:
            result = await self.parent.api.set_screen_lock(locked)
            screen_lock = result.get("screenLock") if isinstance(result, dict) else None
            if isinstance(screen_lock, dict):
                self.coordinator.async_set_updated_data(_with_lock_data(self.coordinator.data, screen_lock))
                hardware = self.parent.hardware_coordinator
                if hardware is not None and isinstance(hardware.data, dict):
                    hardware_data = dict(hardware.data)
                    hardware_data["screenLock"] = dict(screen_lock)
                    hardware_data["screen_lock"] = dict(screen_lock)
                    hardware.async_set_updated_data(hardware_data)
            await self.coordinator.async_request_refresh()
        except Exception as exc:
            action = "lock" if locked else "unlock"
            raise HomeAssistantError(f"Could not {action} the thermostat screen: {exc}") from exc

    async def async_lock(self, **kwargs: Any) -> None:
        await self._async_set_locked(True)

    async def async_unlock(self, **kwargs: Any) -> None:
        await self._async_set_locked(False)
