"""Lock platform for the IHA thermostat screen."""

from __future__ import annotations

from typing import Any

from homeassistant.components.lock import LockEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator
from .entity import IhaCoordinatorEntity, panel_serial


def _lock_data(data: object) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    value = data.get("screenLock", data.get("screen_lock"))
    return value if isinstance(value, dict) else {}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    parent: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    if parent.hardware_coordinator is not None:
        async_add_entities([IhaScreenLock(entry, parent, parent.hardware_coordinator)])


class IhaScreenLock(CoordinatorEntity[IhaHardwareCoordinator], LockEntity):
    """Control the normal tap/guest screen lock from Home Assistant."""

    _attr_name = "Screen Lock"
    _attr_icon = "mdi:tablet-lock"

    def __init__(
        self,
        entry: ConfigEntry,
        parent: IhaCoordinator,
        coordinator: IhaHardwareCoordinator,
    ) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_screen_lock"

    def _data(self) -> dict[str, Any]:
        return _lock_data(self.coordinator.data)


    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

    @property
    def is_locked(self) -> bool:
        return bool(self._data().get("locked"))

    @property
    def available(self) -> bool:
        return bool(self.coordinator.last_update_success and self._data())

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        lock = self._data()
        return {
            "lock_mode": lock.get("mode"),
            "security_locked": bool(lock.get("securityLocked", lock.get("security_locked", False))),
            "updated_at": lock.get("updatedAt", lock.get("updated_at")),
        }

    async def _async_set_locked(self, locked: bool) -> None:
        try:
            result = await self.parent.api.set_screen_lock(locked)
            screen_lock = result.get("screenLock") if isinstance(result, dict) else None
            if isinstance(screen_lock, dict):
                current = dict(self.coordinator.data) if isinstance(self.coordinator.data, dict) else {}
                current["screenLock"] = screen_lock
                self.coordinator.async_set_updated_data(current)
            await self.coordinator.async_request_refresh()
        except Exception as exc:
            action = "lock" if locked else "unlock"
            raise HomeAssistantError(f"Could not {action} the thermostat screen: {exc}") from exc

    async def async_lock(self, **kwargs: Any) -> None:
        await self._async_set_locked(True)

    async def async_unlock(self, **kwargs: Any) -> None:
        await self._async_set_locked(False)
