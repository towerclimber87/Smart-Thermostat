"""Select controls for the IHA onboard motion sensor."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaHardwareEntity

PARALLEL_UPDATES = 1


@dataclass(frozen=True)
class MotionSelectSpec:
    key: str
    name: str
    unique_suffix: str
    icon: str
    option_to_value: dict[str, int]


MOTION_SELECTS = (
    MotionSelectSpec(
        key="sensitivityLevel",
        name="Motion Sensitivity",
        unique_suffix="motion_sensitivity",
        icon="mdi:tune-variant",
        option_to_value={"Maximum": 0, "Reduced": 25},
    ),
    MotionSelectSpec(
        key="pollSeconds",
        name="Motion Check Delay",
        unique_suffix="motion_check_delay",
        icon="mdi:timer-refresh-outline",
        option_to_value={"1 second": 1, "3 seconds": 3, "6 seconds": 6},
    ),
    MotionSelectSpec(
        key="onTimeSeconds",
        name="Motion Hold Time",
        unique_suffix="motion_hold_time",
        icon="mdi:timer-sand",
        option_to_value={"2 seconds": 2, "10 minutes": 600},
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up motion configuration controls."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    hardware_coordinator = panel_coordinator.hardware_coordinator
    if hardware_coordinator is None:
        return
    async_add_entities(
        [
            IhaMotionSelect(hardware_coordinator, panel_coordinator, entry, spec)
            for spec in MOTION_SELECTS
        ]
    )


class IhaMotionSelect(IhaHardwareEntity, SelectEntity):
    """A motion configuration value with explicit, non-analog choices."""

    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, coordinator, panel_coordinator, entry, spec: MotionSelectSpec) -> None:
        super().__init__(coordinator, panel_coordinator, entry, spec.unique_suffix)
        self.spec = spec
        self._attr_name = spec.name
        self._attr_icon = spec.icon
        self._attr_options = list(spec.option_to_value)

    @property
    def available(self) -> bool:
        return bool(super().available and self.motion_data.get("available"))

    @property
    def current_option(self) -> str | None:
        config = self.motion_data.get("config")
        if not isinstance(config, dict):
            return None
        value = config.get(self.spec.key)
        try:
            numeric = int(value)
        except (TypeError, ValueError):
            return None
        for option, mapped in self.spec.option_to_value.items():
            if numeric == mapped:
                return option
        return None

    async def async_select_option(self, option: str) -> None:
        if option not in self.spec.option_to_value:
            raise ValueError(f"Unsupported {self.spec.name} option: {option}")
        await self.coordinator.async_set_motion_config(
            {self.spec.key: self.spec.option_to_value[option]}
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        motion = self.motion_data
        electrical = motion.get("electrical") if isinstance(motion.get("electrical"), dict) else {}
        return {
            "hardware_control_key": self.spec.key,
            "stable_board_levels": electrical.get("stableBoardLevels"),
            "electrical_note": electrical.get("note"),
        }
