"""Select controls for IHA motion hardware."""

from __future__ import annotations

from typing import Any

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator
from .entity import IhaCoordinatorEntity, panel_serial


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    parent: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    hardware = parent.hardware_coordinator
    if hardware is None:
        return
    async_add_entities([
        IhaMotionSelect(entry, parent, hardware, "pollSeconds", "Motion polling", {"1 second": 1, "3 seconds": 3, "6 seconds": 6}),
        IhaMotionSelect(entry, parent, hardware, "sensitivityLevel", "Motion sensitivity", {"Maximum": 0, "Reduced": 25}),
        IhaMotionSelect(entry, parent, hardware, "onTimeSeconds", "Motion hold time", {"2 seconds": 2, "10 minutes": 600}),
    ])


class IhaMotionSelect(CoordinatorEntity[IhaHardwareCoordinator], SelectEntity):
    _attr_has_entity_name = True

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaHardwareCoordinator, key: str, name: str, options: dict[str, int]) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self.key = key
        self.values = options
        self._attr_name = name
        self._attr_options = list(options)
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_{key}"

    @property
    def current_option(self) -> str | None:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        config = motion.get("config") if isinstance(motion.get("config"), dict) else {}
        raw = config.get(self.key)
        for option, value in self.values.items():
            if raw == value:
                return option
        return None

    async def async_select_option(self, option: str) -> None:
        if option not in self.values:
            return
        await self.coordinator.api.set_motion({self.key: self.values[option]})
        await self.coordinator.async_request_refresh()

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info
