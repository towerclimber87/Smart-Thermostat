"""Sensor platform for IHA panel telemetry."""

from __future__ import annotations

from typing import Any, Callable

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import PERCENTAGE, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator
from .entity import IhaCoordinatorEntity, climate_data, panel_serial


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    entities: list[SensorEntity] = [
        IhaStatusSensor(entry, coordinator, "outdoor_temperature", "Outdoor temperature", "mdi:thermometer", UnitOfTemperature.FAHRENHEIT, SensorDeviceClass.TEMPERATURE),
        IhaStatusSensor(entry, coordinator, "humidity", "Humidity", "mdi:water-percent", PERCENTAGE, SensorDeviceClass.HUMIDITY),
    ]
    if coordinator.hardware_coordinator is not None:
        entities.append(IhaLocalTemperatureSensor(entry, coordinator, coordinator.hardware_coordinator))
    async_add_entities(entities)


class IhaStatusSensor(IhaCoordinatorEntity, SensorEntity):
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(
        self,
        entry: ConfigEntry,
        coordinator: IhaCoordinator,
        key: str,
        name: str,
        icon: str,
        unit: str,
        device_class: SensorDeviceClass,
    ) -> None:
        super().__init__(entry, coordinator)
        self._key = key
        self._attr_name = name
        self._attr_icon = icon
        self._attr_native_unit_of_measurement = unit
        self._attr_device_class = device_class
        self._attr_unique_id = f"{self._serial}_{key}"

    @property
    def native_value(self) -> float | None:
        data = climate_data(self.coordinator.data)
        keys = ("outdoor_temperature", "outdoorTemp") if self._key == "outdoor_temperature" else (self._key,)
        for key in keys:
            if key in data:
                try:
                    return float(data[key])
                except (TypeError, ValueError):
                    return None
        return None


class IhaLocalTemperatureSensor(CoordinatorEntity[IhaHardwareCoordinator], SensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Panel temperature"
    _attr_icon = "mdi:thermometer-lines"
    _attr_device_class = SensorDeviceClass.TEMPERATURE
    _attr_native_unit_of_measurement = UnitOfTemperature.FAHRENHEIT
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaHardwareCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_panel_temperature"

    @property
    def native_value(self) -> float | None:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        item = data.get("temperature") or data.get("localTempSensor")
        if not isinstance(item, dict) or not item.get("available"):
            return None
        try:
            return float(item.get("temperatureF"))
        except (TypeError, ValueError):
            return None

    @property
    def available(self) -> bool:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        item = data.get("temperature") or data.get("localTempSensor")
        return bool(self.coordinator.last_update_success and isinstance(item, dict) and item.get("available"))

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info
