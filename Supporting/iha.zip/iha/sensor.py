"""Sensor platform for IHA onboard HDC2080 devices."""

from __future__ import annotations

from typing import Any

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaHardwareEntity

PARALLEL_UPDATES = 0
HDC2080_ADDRESSES = ("0x40", "0x41")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up both onboard HDC2080 temperature sensors."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    hardware_coordinator = panel_coordinator.hardware_coordinator
    if hardware_coordinator is None:
        return
    async_add_entities(
        [
            IhaHdc2080TemperatureSensor(
                hardware_coordinator,
                panel_coordinator,
                entry,
                address,
            )
            for address in HDC2080_ADDRESSES
        ]
    )


class IhaHdc2080TemperatureSensor(IhaHardwareEntity, SensorEntity):
    """One physical HDC2080 temperature reading."""

    _attr_device_class = SensorDeviceClass.TEMPERATURE
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_native_unit_of_measurement = UnitOfTemperature.FAHRENHEIT
    _attr_suggested_display_precision = 1
    _attr_icon = "mdi:thermometer"

    def __init__(self, coordinator, panel_coordinator, entry, address: str) -> None:
        suffix = address.lower().replace("0x", "")
        super().__init__(coordinator, panel_coordinator, entry, f"hdc2080_{suffix}_temperature")
        try:
            self.address = f"0x{int(address, 16):02X}"
        except (TypeError, ValueError):
            self.address = str(address or "").strip()
        self._attr_name = f"Onboard Temperature {self.address}"

    @property
    def sensor_data(self) -> dict[str, Any]:
        sensors = self.temperature_data.get("sensors")
        if not isinstance(sensors, list):
            return {}
        for item in sensors:
            if not isinstance(item, dict):
                continue
            if str(item.get("address") or "").strip().lower() == self.address.lower():
                return item
        return {}

    @property
    def available(self) -> bool:
        item = self.sensor_data
        return bool(
            super().available
            and item.get("available")
            and item.get("temperatureF") is not None
        )

    @property
    def native_value(self) -> float | None:
        value = self.sensor_data.get("temperatureF")
        try:
            return round(float(value), 2) if value is not None else None
        except (TypeError, ValueError):
            return None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        item = self.sensor_data
        temperature = self.temperature_data
        diagnostics = self.hardware_diagnostics
        return {
            "i2c_address": self.address,
            "humidity": item.get("humidity"),
            "temperature_celsius": item.get("temperatureC"),
            "used_for_thermostat_control": bool(item.get("used")),
            "ignored_reason": item.get("ignoredReason"),
            "pair_strategy": temperature.get("strategy"),
            "pair_degraded": bool(temperature.get("degraded")),
            "pair_temperature_delta_f": temperature.get("temperatureDeltaF"),
            "pair_max_allowed_delta_f": temperature.get("maxAllowedDeltaF"),
            "read_at": temperature.get("readAt") or self.hardware_data.get("readAt"),
            "telemetry_source": "cached" if diagnostics.get("using_cached_status") else "live",
            "telemetry_poll_seconds": diagnostics.get("poll_seconds"),
        }
