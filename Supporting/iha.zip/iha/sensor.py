"""Sensor platform for IHA panel telemetry."""

from __future__ import annotations

from typing import Any, Callable

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import PERCENTAGE, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator
from .entity import IhaCoordinatorEntity, climate_data, panel_serial


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    entities: list[SensorEntity] = [
        IhaStatusSensor(entry, coordinator, "outdoor_temperature", "Outdoor temperature", "mdi:thermometer", UnitOfTemperature.FAHRENHEIT, SensorDeviceClass.TEMPERATURE),
        IhaStatusSensor(entry, coordinator, "humidity", "Humidity", "mdi:water-percent", PERCENTAGE, SensorDeviceClass.HUMIDITY),
    ]
    if coordinator.hardware_coordinator is not None:
        hardware = coordinator.hardware_coordinator
        entities.extend(
            [
                IhaLocalTemperatureSensor(entry, coordinator, hardware),
                IhaIndividualTemperatureSensor(entry, coordinator, hardware, 0),
                IhaIndividualTemperatureSensor(entry, coordinator, hardware, 1),
            ]
        )
    async_add_entities(entities)


class IhaStatusSensor(IhaCoordinatorEntity, SensorEntity):
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(
        self,
        entry: ConfigEntry,
        coordinator: IhaCoordinator,
        key: str,
        name: str,
        icon: str,
        unit: str,
        device_class: SensorDeviceClass,
    ) -> None:
        super().__init__(entry, coordinator)
        self._key = key
        self._attr_name = name
        self._attr_icon = icon
        self._attr_native_unit_of_measurement = unit
        self._attr_device_class = device_class
        self._attr_unique_id = f"{self._serial}_{key}"

    @property
    def native_value(self) -> float | None:
        data = climate_data(self.coordinator.data)
        keys = ("outdoor_temperature", "outdoorTemp") if self._key == "outdoor_temperature" else (self._key,)
        for key in keys:
            if key in data:
                try:
                    return float(data[key])
                except (TypeError, ValueError):
                    return None
        return None


class IhaLocalTemperatureSensor(CoordinatorEntity[IhaHardwareCoordinator], SensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Panel temperature"
    _attr_icon = "mdi:thermometer-lines"
    _attr_device_class = SensorDeviceClass.TEMPERATURE
    _attr_native_unit_of_measurement = UnitOfTemperature.FAHRENHEIT
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaHardwareCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_panel_temperature"

    @property
    def native_value(self) -> float | None:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        item = data.get("temperature") or data.get("localTempSensor")
        if not isinstance(item, dict) or not item.get("available"):
            return None
        try:
            return float(item.get("temperatureF"))
        except (TypeError, ValueError):
            return None

    @property
    def available(self) -> bool:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        item = data.get("temperature") or data.get("localTempSensor")
        return bool(self.coordinator.last_update_success and isinstance(item, dict) and item.get("available"))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        item = data.get("temperature") or data.get("localTempSensor")
        if not isinstance(item, dict):
            return {}
        attributes: dict[str, Any] = {}
        for source_key, attribute_key in (
            ("strategy", "selection_strategy"),
            ("primarySensor", "primary_sensor"),
            ("activeSensor", "active_sensor"),
            ("healthFlag", "health_flag"),
            ("healthStatus", "health_status"),
            ("healthMessage", "health_message"),
            ("temperatureDeltaF", "sensor_difference_f"),
            ("maxAllowedDeltaF", "maximum_difference_f"),
            ("maxJumpF", "sudden_jump_limit_f"),
        ):
            value = item.get(source_key)
            if value not in (None, ""):
                attributes[attribute_key] = value
        return attributes

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info


class IhaIndividualTemperatureSensor(CoordinatorEntity[IhaHardwareCoordinator], SensorEntity):
    """Expose one corrected onboard HDC2080 reading with raw diagnostics."""

    _attr_has_entity_name = True
    _attr_icon = "mdi:thermometer"
    _attr_device_class = SensorDeviceClass.TEMPERATURE
    _attr_native_unit_of_measurement = UnitOfTemperature.FAHRENHEIT
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_suggested_display_precision = 1

    def __init__(
        self,
        entry: ConfigEntry,
        parent: IhaCoordinator,
        coordinator: IhaHardwareCoordinator,
        sensor_index: int,
    ) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._sensor_index = sensor_index
        sensor_number = sensor_index + 1
        self._attr_name = f"Temperature sensor {sensor_number}"
        self._attr_unique_id = f"{self._serial}_panel_temperature_sensor_{sensor_number}"

    def _sensor_payload(self) -> dict[str, Any] | None:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        combined = data.get("temperature") or data.get("localTempSensor")
        if not isinstance(combined, dict):
            return None
        raw_sensors = combined.get("sensors")
        if not isinstance(raw_sensors, list):
            return None

        # The configured HDC2080 pair normally uses 0x40 and 0x41. Sorting by
        # I2C address keeps sensor 1 and sensor 2 stable even when one reading
        # fails and the backend returns successful and failed items separately.
        addressable: list[dict[str, Any]] = []
        for item in raw_sensors:
            if not isinstance(item, dict):
                continue
            address = str(item.get("address") or "").strip().lower()
            if not address.startswith("0x"):
                continue
            try:
                int(address, 16)
            except ValueError:
                continue
            addressable.append(item)
        addressable.sort(key=lambda item: int(str(item.get("address")), 16))

        if self._sensor_index >= len(addressable):
            return None
        return addressable[self._sensor_index]

    @property
    def native_value(self) -> float | None:
        item = self._sensor_payload()
        if not item or not item.get("available"):
            return None
        try:
            return float(item.get("temperatureF"))
        except (TypeError, ValueError):
            return None

    @property
    def available(self) -> bool:
        item = self._sensor_payload()
        return bool(
            self.coordinator.last_update_success
            and item
            and item.get("available")
            and item.get("temperatureF") is not None
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        item = self._sensor_payload() or {}
        attributes: dict[str, Any] = {}
        for source_key, attribute_key in (
            ("sensorNumber", "sensor_number"),
            ("address", "i2c_address"),
            ("rawTemperatureF", "raw_temperature_f"),
            ("rawTemperatureC", "raw_temperature_c"),
            ("offsetF", "temperature_offset_f"),
            ("temperatureC", "adjusted_temperature_c"),
            ("humidity", "humidity"),
            ("healthy", "healthy"),
            ("healthStatus", "health_status"),
            ("jumpDeltaF", "last_jump_f"),
            ("used", "used_for_panel_temperature"),
            ("ignoredReason", "ignored_reason"),
            ("error", "error"),
        ):
            value = item.get(source_key)
            if value not in (None, ""):
                attributes[attribute_key] = value
        return attributes

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

