"""Persistent shared JARVIS knowledge for the IHA integration."""

from __future__ import annotations

import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import math
import re
from typing import Any

from homeassistant.core import HomeAssistant, State
from homeassistant.exceptions import ServiceValidationError
from homeassistant.helpers.storage import Store

from .const import DOMAIN

STORAGE_VERSION = 1
STORAGE_KEY = f"{DOMAIN}.jarvis_knowledge"

_UNKNOWN_STATES = {"", "unknown", "unavailable", "none", "null"}
_TEMPERATURE_UNITS = {
    "c": "°C",
    "°c": "°C",
    "celsius": "°C",
    "f": "°F",
    "°f": "°F",
    "fahrenheit": "°F",
    "k": "K",
    "kelvin": "K",
}


def _utc_now() -> str:
    """Return a compact UTC timestamp."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize_knowledge_key(value: object) -> str:
    """Normalize a spoken/display knowledge key into a stable storage key."""
    text = str(value or "").strip().lower()
    text = re.sub(r"\b(the|a|an|reading|source|sensor|thermostat)\b", " ", text)
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    if not text:
        raise ServiceValidationError("Knowledge key cannot be blank.")
    return text[:96]


def _clean_text(value: object, limit: int = 255) -> str:
    return " ".join(str(value or "").strip().split())[:limit]


def _normalize_unit(value: object) -> str:
    raw = str(value or "").strip()
    return _TEMPERATURE_UNITS.get(raw.lower(), raw)


def _temperature_convert(value: float, source_unit: str, target_unit: str) -> float:
    """Convert a temperature without depending on optional HA converter APIs."""
    source = _normalize_unit(source_unit)
    target = _normalize_unit(target_unit)
    if not source or not target or source == target:
        return value
    if source == "°C":
        celsius = value
    elif source == "°F":
        celsius = (value - 32.0) * 5.0 / 9.0
    elif source == "K":
        celsius = value - 273.15
    else:
        return value
    if target == "°C":
        return celsius
    if target == "°F":
        return (celsius * 9.0 / 5.0) + 32.0
    if target == "K":
        return celsius + 273.15
    return value


def _as_number(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _infer_attribute(state: State, category: str, requested: str) -> str:
    requested = _clean_text(requested, 96)
    if requested and requested.lower() not in {"state", "none"}:
        if requested not in state.attributes:
            raise ServiceValidationError(
                f"{state.entity_id} does not currently have an attribute named {requested}."
            )
        return requested
    domain = state.entity_id.split(".", 1)[0]
    if category == "temperature":
        if domain == "climate" and "current_temperature" in state.attributes:
            return "current_temperature"
        if domain == "weather" and "temperature" in state.attributes:
            return "temperature"
        if _as_number(state.state) is not None:
            return ""
        for candidate in ("current_temperature", "temperature"):
            if candidate in state.attributes and _as_number(state.attributes.get(candidate)) is not None:
                return candidate
        raise ServiceValidationError(
            f"{state.entity_id} does not expose a usable temperature state or attribute."
        )
    return ""


def _unit_for_state(state: State, attribute: str) -> str:
    attrs = state.attributes
    if attribute in {"current_temperature", "temperature"}:
        return _normalize_unit(
            attrs.get("temperature_unit")
            or attrs.get("unit_of_measurement")
            or attrs.get("unit")
        )
    return _normalize_unit(attrs.get("unit_of_measurement") or attrs.get("unit"))


class JarvisKnowledgeStore:
    """Single Home Assistant-owned knowledge store shared by every IHA panel."""

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._store: Store[dict[str, Any]] = Store(hass, STORAGE_VERSION, STORAGE_KEY)
        self._lock = asyncio.Lock()
        self._data: dict[str, Any] = {"updated_at": "", "items": {}}

    async def async_load(self) -> None:
        """Load stored mappings once during integration setup."""
        stored = await self._store.async_load()
        if isinstance(stored, dict) and isinstance(stored.get("items"), dict):
            self._data = {
                "updated_at": _clean_text(stored.get("updated_at"), 64),
                "items": deepcopy(stored.get("items") or {}),
            }

    async def async_remember(
        self,
        *,
        key: str,
        entity_id: str,
        attribute: str = "",
        display_name: str = "",
        category: str = "temperature",
        inside: bool | None = None,
        aliases: list[str] | None = None,
    ) -> dict[str, Any]:
        """Validate and persist one exact Home Assistant source mapping."""
        normalized_key = normalize_knowledge_key(key)
        state = self.hass.states.get(entity_id)
        if state is None:
            raise ServiceValidationError(f"Home Assistant entity {entity_id} was not found.")
        category = normalize_knowledge_key(category or "general")
        resolved_attribute = _infer_attribute(state, category, attribute)
        friendly_name = _clean_text(state.attributes.get("friendly_name") or entity_id)
        label = _clean_text(display_name) or normalized_key.replace("_", " ").title()
        if inside is None:
            inside = not any(word in normalized_key for word in ("outside", "outdoor", "exterior"))
        cleaned_aliases: list[str] = []
        seen: set[str] = set()
        for alias in [label, normalized_key.replace("_", " "), *(aliases or [])]:
            cleaned = _clean_text(alias, 96)
            marker = cleaned.casefold()
            if cleaned and marker not in seen:
                seen.add(marker)
                cleaned_aliases.append(cleaned)
        item = {
            "key": normalized_key,
            "display_name": label,
            "category": category,
            "entity_id": state.entity_id,
            "attribute": resolved_attribute,
            "inside": bool(inside),
            "aliases": cleaned_aliases[:16],
            "source_name": friendly_name,
            "created_at": _utc_now(),
            "updated_at": _utc_now(),
        }
        async with self._lock:
            existing = self._data["items"].get(normalized_key)
            if isinstance(existing, dict) and existing.get("created_at"):
                item["created_at"] = existing["created_at"]
            self._data["items"][normalized_key] = item
            self._data["updated_at"] = item["updated_at"]
            await self._store.async_save(deepcopy(self._data))
        return self._resolved_item(item)

    async def async_forget(self, key: str) -> dict[str, Any]:
        """Delete one mapping by normalized key."""
        normalized_key = normalize_knowledge_key(key)
        async with self._lock:
            removed = self._data["items"].pop(normalized_key, None)
            if removed is None:
                raise ServiceValidationError(f"No shared JARVIS knowledge is saved as {normalized_key}.")
            self._data["updated_at"] = _utc_now()
            await self._store.async_save(deepcopy(self._data))
        return {"key": normalized_key, "removed": True, "item": removed}

    async def async_get(
        self,
        *,
        keys: list[str] | None = None,
        category: str = "",
        inside: bool | None = None,
    ) -> dict[str, Any]:
        """Return stored mappings with freshly resolved Home Assistant values."""
        wanted = {normalize_knowledge_key(key) for key in (keys or []) if str(key or "").strip()}
        normalized_category = normalize_knowledge_key(category) if str(category or "").strip() else ""
        async with self._lock:
            items = deepcopy(self._data.get("items") or {})
            updated_at = self._data.get("updated_at") or ""
        resolved: list[dict[str, Any]] = []
        for key in sorted(items):
            item = items.get(key)
            if not isinstance(item, dict):
                continue
            if wanted and key not in wanted:
                continue
            if normalized_category and item.get("category") != normalized_category:
                continue
            if inside is not None and bool(item.get("inside")) != bool(inside):
                continue
            resolved.append(self._resolved_item(item))
        return {
            "storage_key": STORAGE_KEY,
            "updated_at": updated_at,
            "count": len(resolved),
            "items": resolved,
            "by_key": {item["key"]: item for item in resolved},
        }

    def _resolved_item(self, item: dict[str, Any]) -> dict[str, Any]:
        result = deepcopy(item)
        entity_id = _clean_text(item.get("entity_id"), 255)
        state = self.hass.states.get(entity_id)
        if state is None:
            result.update({"available": False, "value": None, "unit": "", "error": "Entity not found"})
            return result
        attribute = _clean_text(item.get("attribute"), 96)
        raw_value: object = state.attributes.get(attribute) if attribute else state.state
        raw_text = "" if raw_value is None else str(raw_value).strip()
        available = state.state.lower() not in _UNKNOWN_STATES and raw_text.lower() not in _UNKNOWN_STATES
        unit = _unit_for_state(state, attribute)
        value: object = raw_value
        if item.get("category") == "temperature":
            number = _as_number(raw_value)
            available = available and number is not None
            if number is not None:
                target_unit = _normalize_unit(getattr(self.hass.config.units, "temperature_unit", ""))
                value = _temperature_convert(number, unit, target_unit)
                if target_unit:
                    unit = target_unit
        result.update(
            {
                "source_name": _clean_text(state.attributes.get("friendly_name") or entity_id),
                "available": bool(available),
                "value": value if available else None,
                "raw_value": raw_value,
                "unit": unit,
                "state": state.state,
                "last_changed": state.last_changed.isoformat(),
                "error": "" if available else "Source is unavailable or does not contain a usable value",
            }
        )
        return result
