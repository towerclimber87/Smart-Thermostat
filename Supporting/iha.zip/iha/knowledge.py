"""Home Assistant-owned shared JARVIS knowledge and profile storage."""

from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .const import DOMAIN

_STORE_VERSION = 1
_STORE_KEY = f"{DOMAIN}.jarvis_knowledge"

_DEFAULT_PROFILE: dict[str, Any] = {
    "name": "JARVIS",
    "routing_mode": "hybrid",
    "local_agent_id": "conversation.home_assistant",
    "cloud_agent_id": "",
    "tts_policy": "local_only",
    "local_tts_entity_id": "",
    "address": "sir",
    "humor_level": 1,
    "use_title": True,
    "updated_at": "",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _normalize_key(value: str) -> str:
    key = re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower()).strip("_")
    return key[:120]


class JarvisKnowledgeStore:
    """Persist shared exact entity mappings for all IHA panels."""

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._store = Store(hass, _STORE_VERSION, _STORE_KEY)
        self._items: dict[str, dict[str, Any]] = {}
        self._profile: dict[str, Any] = dict(_DEFAULT_PROFILE)

    async def async_load(self) -> None:
        payload = await self._store.async_load()
        if not isinstance(payload, dict):
            return
        raw_items = payload.get("items") or payload.get("knowledge")
        if isinstance(raw_items, dict):
            self._items = {str(k): dict(v) for k, v in raw_items.items() if isinstance(v, dict)}
        raw_profile = payload.get("profile")
        if isinstance(raw_profile, dict):
            self._profile.update({k: v for k, v in raw_profile.items() if k in _DEFAULT_PROFILE})

    async def _save(self) -> None:
        await self._store.async_save({"items": self._items, "profile": self._profile})

    async def async_remember(
        self,
        *,
        key: str,
        entity_id: str,
        attribute: str = "",
        display_name: str = "",
        category: str = "temperature",
        inside: bool | None = None,
        aliases: list[str] | None = None,
    ) -> dict[str, Any]:
        normalized = _normalize_key(key)
        if not normalized:
            raise ValueError("Knowledge key cannot be blank.")
        entity_id = str(entity_id or "").strip()
        state = self.hass.states.get(entity_id)
        domain = entity_id.split(".", 1)[0] if "." in entity_id else ""
        if not attribute:
            if domain == "climate":
                attribute = "current_temperature"
            elif domain == "weather":
                attribute = "temperature"
        if inside is None:
            inside = "outside" not in normalized and "outdoor" not in normalized
        record = {
            "key": normalized,
            "entity_id": entity_id,
            "attribute": str(attribute or "").strip(),
            "display_name": str(display_name or normalized.replace("_", " ").title()).strip(),
            "category": str(category or "temperature").strip().lower(),
            "inside": bool(inside),
            "aliases": [str(value).strip() for value in (aliases or []) if str(value).strip()],
            "updated_at": _now(),
        }
        self._items[normalized] = record
        await self._save()
        return self._live_item(record)

    async def async_forget(self, key: str) -> dict[str, Any]:
        normalized = _normalize_key(key)
        removed = self._items.pop(normalized, None)
        await self._save()
        return {"removed": bool(removed), "key": normalized}

    async def async_get(
        self,
        *,
        keys: list[str] | None = None,
        category: str = "",
        inside: bool | None = None,
    ) -> dict[str, Any]:
        wanted = {_normalize_key(value) for value in (keys or []) if _normalize_key(value)}
        items: list[dict[str, Any]] = []
        for key in sorted(self._items):
            record = self._items[key]
            if wanted and key not in wanted:
                continue
            if category and str(record.get("category") or "") != category:
                continue
            if inside is not None and bool(record.get("inside")) is not bool(inside):
                continue
            items.append(self._live_item(record))
        return {"items": items, "count": len(items)}

    async def async_get_profile(self) -> dict[str, Any]:
        return {"profile": dict(self._profile)}

    async def async_set_profile(self, **changes: Any) -> dict[str, Any]:
        for key, value in changes.items():
            if key not in _DEFAULT_PROFILE:
                continue
            if key in {"local_agent_id", "cloud_agent_id", "local_tts_entity_id"}:
                value = str(value or "").strip()
            elif key == "address":
                value = str(value or "sir").strip(" ,.!?")[:32] or "sir"
            elif key == "humor_level":
                value = max(0, min(2, int(value)))
            elif key == "use_title":
                value = bool(value)
            self._profile[key] = value
        self._profile["updated_at"] = _now()
        await self._save()
        return {"profile": dict(self._profile)}

    def _live_item(self, record: dict[str, Any]) -> dict[str, Any]:
        item = dict(record)
        state = self.hass.states.get(str(record.get("entity_id") or ""))
        attribute = str(record.get("attribute") or "")
        available = state is not None and state.state not in {"unknown", "unavailable"}
        raw_value: Any = None
        unit = ""
        source_name = str(record.get("entity_id") or "")
        if state is not None:
            source_name = str(state.attributes.get("friendly_name") or state.entity_id)
            raw_value = state.attributes.get(attribute) if attribute else state.state
            unit = str(state.attributes.get("unit_of_measurement") or state.attributes.get("temperature_unit") or "")
            if raw_value is None:
                available = False
        try:
            value: Any = float(raw_value) if raw_value is not None else None
        except (TypeError, ValueError):
            value = raw_value
        item.update(
            {
                "source_name": source_name,
                "available": available,
                "value": value,
                "unit": unit,
            }
        )
        return item
