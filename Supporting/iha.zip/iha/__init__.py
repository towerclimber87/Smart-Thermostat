"""IHA integration."""

from __future__ import annotations

import importlib

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_PORT, Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import IhaApi
from .const import CONF_SERIAL, DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator

PLATFORMS: list[Platform] = [Platform.CLIMATE]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up IHA from a config entry."""
    session = async_get_clientsession(hass)
    api = IhaApi(session, entry.data[CONF_HOST], entry.data.get(CONF_PORT, 8080))
    coordinator = IhaCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    def _current_panel_data() -> dict:
        data = coordinator.data or {}
        climate = data.get("climate") or data.get("thermostat")
        return climate if isinstance(climate, dict) else data

    def _panel_serial() -> str:
        data = coordinator.data or {}
        climate = _current_panel_data()
        # Prefer the live panel-provided id over the saved entry id. This lets
        # existing entries recover from old builds that used a cloned
        # /etc/machine-id as the serial.
        return str(
            data.get("serial")
            or data.get("unique_id")
            or data.get("id")
            or data.get("hardware_id")
            or data.get("mac_address")
            or climate.get("serial")
            or climate.get("unique_id")
            or climate.get("id")
            or climate.get("hardware_id")
            or climate.get("mac_address")
            or entry.data.get(CONF_SERIAL)
            or entry.unique_id
            or f"{api.host}:{api.port}"
        ).strip()

    def _sync_entry_metadata() -> None:
        data = coordinator.data or {}
        climate = _current_panel_data()
        name = str(climate.get("name") or data.get("name") or DEFAULT_NAME).strip() or DEFAULT_NAME
        serial = _panel_serial()
        updates: dict[str, object] = {}
        if serial and entry.data.get(CONF_SERIAL) != serial:
            updates[CONF_SERIAL] = serial
        update_kwargs: dict[str, object] = {}
        if updates:
            update_kwargs["data"] = {**entry.data, **updates}
        if serial and entry.unique_id != serial:
            update_kwargs["unique_id"] = serial
        if entry.title != name:
            update_kwargs["title"] = name
        if update_kwargs:
            hass.config_entries.async_update_entry(entry, **update_kwargs)

    _sync_entry_metadata()
    entry.async_on_unload(coordinator.async_add_listener(_sync_entry_metadata))
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    # Pre-load the platform module in Home Assistant's executor. Home Assistant
    # imports modules using importlib, which can touch disk and block the event
    # loop if the platform is first imported during setup forwarding.
    await hass.async_add_executor_job(importlib.import_module, f"{__name__}.climate")
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unload_ok
