"""IHA integration."""

from __future__ import annotations

import asyncio
import importlib
import logging
from datetime import datetime, timezone
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry, ConfigEntryState
from homeassistant.const import CONF_HOST, CONF_PORT, Platform
from homeassistant.core import HomeAssistant, ServiceCall, ServiceResponse, SupportsResponse
from homeassistant.exceptions import ConfigEntryNotReady, HomeAssistantError, ServiceValidationError
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.storage import Store
from homeassistant.helpers.typing import ConfigType
from homeassistant.util import slugify

from .api import IhaApi
from .const import (
    ATTR_AGENT_ID,
    ATTR_ALIASES,
    ATTR_ATTRIBUTE,
    ATTR_CATEGORY,
    ATTR_COMMAND,
    ATTR_MESSAGE,
    ATTR_ANNOUNCEMENT_VOLUME_PERCENT,
    ATTR_DISPLAY_NAME,
    ATTR_ENTITY_ID,
    ATTR_CONFIG_ENTRY,
    ATTR_CONFIG_ENTRY_ID,
    ATTR_FUN_MODE,
    ATTR_INSIDE,
    ATTR_KEY,
    ATTR_KEYS,
    ATTR_LANGUAGE,
    ATTR_MEDIA_PLAYER_ID,
    ATTR_NEW_CONVERSATION,
    ATTR_PLAYFUL_REPLIES,
    ATTR_SPEAK,
    ATTR_TTS_ENTITY_ID,
    ATTR_ROUTING_MODE,
    ATTR_LOCAL_AGENT_ID,
    ATTR_CLOUD_AGENT_ID,
    ATTR_TTS_POLICY,
    ATTR_LOCAL_TTS_ENTITY_ID,
    ATTR_ADDRESS,
    ATTR_HUMOR_LEVEL,
    ATTR_USE_TITLE,
    CONF_SERIAL,
    DATA_JARVIS_KNOWLEDGE,
    DATA_JARVIS_PROFILE,
    DEFAULT_NAME,
    DOMAIN,
    SERVICE_ASK_JARVIS,
    SERVICE_JARVIS_ANNOUNCEMENT,
    SERVICE_FORGET_KNOWLEDGE,
    SERVICE_GET_KNOWLEDGE,
    SERVICE_REMEMBER_KNOWLEDGE,
    SERVICE_GET_JARVIS_PROFILE,
    SERVICE_SET_JARVIS_PROFILE,
)
from .coordinator import IhaCoordinator, IhaHardwareCoordinator, IhaUpdateCoordinator
from .knowledge import JarvisKnowledgeStore

_LOGGER = logging.getLogger(__name__)

DATA_JARVIS_VOLUME_STORE = "jarvis_volume_store"
JARVIS_VOLUME_STORE_VERSION = 1
JARVIS_VOLUME_STORE_KEY = f"{DOMAIN}.jarvis_volume"
DEFAULT_JARVIS_VOLUME_PERCENT = 45
JARVIS_VOLUME_SETTLE_SECONDS = 0.4


def _utc_now_iso() -> str:
    """Return a compact UTC timestamp for the persistent volume cache."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _jarvis_volume_percent_from_data(data: object) -> int | None:
    """Read the panel's JARVIS volume from any supported status layout."""
    if not isinstance(data, dict):
        return None

    containers: list[dict[str, Any]] = [data]
    for key in ("climate", "thermostat", "assistant", "jarvis"):
        value = data.get(key)
        if isinstance(value, dict) and value not in containers:
            containers.append(value)

    percent_keys = (
        "jarvisVolumePercent",
        "jarvis_volume_percent",
        "announcementVolumePercent",
        "announcement_volume_percent",
    )
    level_keys = (
        "jarvisVolumeLevel",
        "jarvis_volume_level",
        "announcementVolumeLevel",
        "announcement_volume_level",
    )

    for container in containers:
        for key in percent_keys:
            if key not in container:
                continue
            try:
                value = float(container[key])
            except (TypeError, ValueError):
                continue
            return max(1, min(100, int(round(value))))
        for key in level_keys:
            if key not in container:
                continue
            try:
                value = float(container[key])
            except (TypeError, ValueError):
                continue
            if value > 1:
                return max(1, min(100, int(round(value))))
            return max(1, min(100, int(round(value * 100))))
    return None


class JarvisVolumeStore:
    """Publish and retain a usable JARVIS volume when a panel is offline."""

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._store = Store(hass, JARVIS_VOLUME_STORE_VERSION, JARVIS_VOLUME_STORE_KEY)
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def async_load(self) -> None:
        """Load the last valid panel volume values from Home Assistant storage."""
        payload = await self._store.async_load()
        entries = payload.get("entries") if isinstance(payload, dict) else None
        if isinstance(entries, dict):
            self._records = {
                str(entry_id): dict(record)
                for entry_id, record in entries.items()
                if isinstance(record, dict)
            }

    def _entity_id_for_entry(self, entry: ConfigEntry, record: dict[str, Any]) -> str:
        entity_id = str(record.get("entity_id") or "").strip()
        if entity_id.startswith("sensor."):
            return entity_id

        object_id = slugify(f"{entry.title or DEFAULT_NAME} jarvis volume") or "iha_jarvis_volume"
        candidate = f"sensor.{object_id}"
        claimed = {
            str(item.get("entity_id") or "")
            for key, item in self._records.items()
            if key != entry.entry_id and isinstance(item, dict)
        }
        if candidate in claimed or self.hass.states.get(candidate) is not None:
            candidate = f"{candidate}_{entry.entry_id[:6].lower()}"
        return candidate

    def _ensure_record(self, entry: ConfigEntry) -> tuple[dict[str, Any], bool]:
        record = self._records.get(entry.entry_id)
        changed = False
        if not isinstance(record, dict):
            record = {}
            self._records[entry.entry_id] = record
            changed = True

        entity_id = self._entity_id_for_entry(entry, record)
        if record.get("entity_id") != entity_id:
            record["entity_id"] = entity_id
            changed = True
        if record.get("panel_name") != entry.title:
            record["panel_name"] = entry.title
            changed = True
        if "volume_percent" not in record:
            record["volume_percent"] = DEFAULT_JARVIS_VOLUME_PERCENT
            record["volume_level"] = round(DEFAULT_JARVIS_VOLUME_PERCENT / 100.0, 2)
            record["fallback_source"] = "default"
            record["last_valid_update"] = ""
            changed = True
        return record, changed

    def _publish(self, entry: ConfigEntry, record: dict[str, Any], source_available: bool) -> None:
        percent = max(1, min(100, int(record.get("volume_percent") or DEFAULT_JARVIS_VOLUME_PERCENT)))
        level = round(percent / 100.0, 2)
        entity_id = str(record["entity_id"])
        self.hass.states.async_set(
            entity_id,
            f"{level:.2f}",
            {
                "friendly_name": f"{entry.title or DEFAULT_NAME} JARVIS Volume",
                "icon": "mdi:volume-high",
                "volume_level": level,
                "volume_percent": percent,
                "source_available": bool(source_available),
                "using_cached_value": not bool(source_available),
                "fallback_source": (
                    "panel"
                    if source_available
                    else str(record.get("fallback_source") or "last_known")
                ),
                "last_valid_update": str(record.get("last_valid_update") or ""),
                "panel_name": entry.title or DEFAULT_NAME,
                "config_entry_id": entry.entry_id,
            },
        )

    async def async_prepare_entries(self, entries: list[ConfigEntry]) -> None:
        """Publish cached/default values before any panel has to be reachable."""
        async with self._lock:
            changed = False
            for entry in entries:
                record, record_changed = self._ensure_record(entry)
                changed = changed or record_changed
                self._publish(entry, record, source_available=False)
            if changed:
                await self._store.async_save({"entries": self._records})

    async def async_update_from_panel(
        self,
        entry: ConfigEntry,
        data: object,
        *,
        source_available: bool,
    ) -> None:
        """Publish a live value or retain the last valid one on poll failure."""
        async with self._lock:
            record, changed = self._ensure_record(entry)
            percent = _jarvis_volume_percent_from_data(data) if source_available else None
            if percent is not None:
                level = round(percent / 100.0, 2)
                if int(record.get("volume_percent") or 0) != percent:
                    record["volume_percent"] = percent
                    record["volume_level"] = level
                    changed = True
                record["fallback_source"] = "last_known"
                if changed or not record.get("last_valid_update"):
                    record["last_valid_update"] = _utc_now_iso()
                    changed = True
            self._publish(entry, record, source_available=source_available and percent is not None)
            if changed:
                await self._store.async_save({"entries": self._records})

    async def async_mark_unavailable(self, entry: ConfigEntry) -> None:
        """Keep the cached state usable while a panel or entry is reloading."""
        async with self._lock:
            record, changed = self._ensure_record(entry)
            self._publish(entry, record, source_available=False)
            if changed:
                await self._store.async_save({"entries": self._records})

    async def async_remove(self, entry: ConfigEntry) -> None:
        """Remove the synthetic sensor when the config entry is deleted."""
        async with self._lock:
            record = self._records.pop(entry.entry_id, None)
            if isinstance(record, dict):
                entity_id = str(record.get("entity_id") or "")
                if entity_id:
                    self.hass.states.async_remove(entity_id)
                await self._store.async_save({"entries": self._records})

SERVICE_REMEMBER_KNOWLEDGE_SCHEMA = vol.Schema(
    {
        vol.Required(ATTR_KEY): vol.All(cv.string, vol.Length(min=1, max=120)),
        vol.Required(ATTR_ENTITY_ID): cv.entity_id,
        vol.Optional(ATTR_ATTRIBUTE, default=""): vol.All(cv.string, vol.Length(max=96)),
        vol.Optional(ATTR_DISPLAY_NAME, default=""): vol.All(cv.string, vol.Length(max=120)),
        vol.Optional(ATTR_CATEGORY, default="temperature"): vol.All(cv.string, vol.Length(min=1, max=64)),
        vol.Optional(ATTR_INSIDE): cv.boolean,
        vol.Optional(ATTR_ALIASES): vol.All(cv.ensure_list, [vol.All(cv.string, vol.Length(min=1, max=96))]),
    }
)

SERVICE_FORGET_KNOWLEDGE_SCHEMA = vol.Schema(
    {vol.Required(ATTR_KEY): vol.All(cv.string, vol.Length(min=1, max=120))}
)

SERVICE_GET_KNOWLEDGE_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_KEYS): vol.All(cv.ensure_list, [vol.All(cv.string, vol.Length(min=1, max=120))]),
        vol.Optional(ATTR_CATEGORY, default=""): vol.All(cv.string, vol.Length(max=64)),
        vol.Optional(ATTR_INSIDE): cv.boolean,
    }
)

SERVICE_GET_JARVIS_PROFILE_SCHEMA = vol.Schema({})

SERVICE_SET_JARVIS_PROFILE_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_ROUTING_MODE): vol.In(["hybrid", "local_only", "cloud_only"]),
        vol.Optional(ATTR_LOCAL_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_CLOUD_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_TTS_POLICY): vol.In(["hybrid", "local_only", "premium_only"]),
        vol.Optional(ATTR_LOCAL_TTS_ENTITY_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_ADDRESS): vol.All(cv.string, vol.Length(min=1, max=32)),
        vol.Optional(ATTR_HUMOR_LEVEL): vol.All(vol.Coerce(int), vol.Range(min=0, max=2)),
        vol.Optional(ATTR_USE_TITLE): cv.boolean,
    }
)

SERVICE_ASK_JARVIS_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_CONFIG_ENTRY): cv.string,
        vol.Optional(ATTR_CONFIG_ENTRY_ID): cv.string,
        vol.Required(ATTR_COMMAND): vol.All(cv.string, vol.Length(min=1, max=1200)),
        vol.Optional(ATTR_SPEAK, default=True): cv.boolean,
        vol.Optional(ATTR_NEW_CONVERSATION, default=False): cv.boolean,
        vol.Optional(ATTR_FUN_MODE, default=False): cv.boolean,
        vol.Optional(ATTR_PLAYFUL_REPLIES, default=True): cv.boolean,
        vol.Optional(ATTR_LANGUAGE, default="en"): vol.All(cv.string, vol.Length(min=1, max=16)),
        vol.Optional(ATTR_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_TTS_ENTITY_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_MEDIA_PLAYER_ID): vol.Any("", None, cv.entity_id),
    }
)

SERVICE_JARVIS_ANNOUNCEMENT_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_CONFIG_ENTRY): cv.string,
        vol.Optional(ATTR_CONFIG_ENTRY_ID): cv.string,
        vol.Required(ATTR_MESSAGE): vol.All(cv.string, vol.Length(min=1, max=1200)),
        vol.Optional(ATTR_LANGUAGE, default="en"): vol.All(cv.string, vol.Length(min=1, max=16)),
        vol.Optional(ATTR_TTS_ENTITY_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_MEDIA_PLAYER_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_ANNOUNCEMENT_VOLUME_PERCENT): vol.All(
            vol.Coerce(int), vol.Range(min=1, max=100)
        ),
    }
)


def _optional_text(data: dict[str, Any], key: str) -> str:
    """Return a trimmed optional service field."""
    return str(data.get(key) or "").strip()


def _jarvis_estimated_speech_seconds(message: str) -> float:
    """Return a conservative TTS duration including pauses and playback tail.

    Home Assistant's TTS action returns before Sonos exposes a dependable
    playback-complete signal. A word-count-only estimate can therefore restore
    volume and clear the panel during a comma, sentence pause, or the final
    syllables. Use the slower of word and character pacing, then add explicit
    punctuation pauses and a small completion buffer.
    """
    text = " ".join(str(message or "").split())
    words = max(1, len(text.split()))
    spoken_characters = sum(1 for character in text if character.isalnum())

    sentence_pause_seconds = sum(text.count(mark) for mark in ".!?") * 0.65
    phrase_pause_seconds = sum(text.count(mark) for mark in ",;:") * 0.32
    dash_pause_seconds = (text.count("—") + text.count("–")) * 0.20

    word_pacing_seconds = words / 2.05
    character_pacing_seconds = spoken_characters / 11.5
    spoken_seconds = max(word_pacing_seconds, character_pacing_seconds)

    estimate = (
        spoken_seconds
        + sentence_pause_seconds
        + phrase_pause_seconds
        + dash_pause_seconds
        + 2.75
    )
    return max(6.0, min(90.0, estimate))


def _jarvis_media_signature(state: Any) -> tuple[str, tuple[str, ...]]:
    """Return a stable media signature without including volume attributes."""
    if state is None:
        return "", ()
    attrs = state.attributes if isinstance(getattr(state, "attributes", None), dict) else {}
    keys = (
        "media_content_id",
        "media_content_type",
        "media_title",
        "media_artist",
        "media_album_name",
        "media_channel",
    )
    return str(getattr(state, "state", "") or ""), tuple(str(attrs.get(key) or "") for key in keys)


async def _async_panel_playback_update(
    coordinator: Any,
    request_id: int,
    action: str,
    *,
    media_player_id: str = "",
    tts_entity_id: str = "",
    estimated_seconds: float = 0.0,
    response_hold_seconds: float = 0.0,
    error: str = "",
) -> None:
    """Best-effort visual synchronization; audio must not fail if the panel is offline."""
    try:
        await coordinator.api.assistant_playback(
            {
                "requestId": int(request_id or 0),
                "action": str(action or "started"),
                "mediaPlayerId": str(media_player_id or ""),
                "ttsEntityId": str(tts_entity_id or ""),
                "estimatedSeconds": float(estimated_seconds or 0.0),
                "responseHoldSeconds": float(response_hold_seconds or 0.0),
                "error": str(error or ""),
            }
        )
    except Exception as exc:  # The Sonos announcement is more important than the overlay callback.
        _LOGGER.debug("Could not update IHA playback state: %s", exc)


async def _async_finish_jarvis_playback(
    hass: HomeAssistant,
    coordinator: Any,
    *,
    request_id: int,
    media_player_id: str,
    tts_entity_id: str,
    baseline_signature: tuple[str, tuple[str, ...]],
    previous_volume: float | None,
    estimated_seconds: float,
    response_hold_seconds: float,
) -> None:
    """Wait for speech to finish, then restore volume and clear the panel.

    Sonos can briefly change its media signature before the spoken announcement
    has actually completed. Treating that first transition back to the baseline
    as completion caused the volume and JARVIS overlay to reset after roughly a
    second. The text-derived duration is therefore a minimum hold, not merely a
    fallback. Observable media-player state may extend the hold, but it may not
    shorten it.
    """
    loop = asyncio.get_running_loop()
    started_at = loop.time()
    minimum_finish_at = started_at + max(2.0, float(estimated_seconds or 0.0))
    deadline = started_at + max(45.0, estimated_seconds * 2.0 + 20.0)
    baseline_state = baseline_signature[0]
    playback_seen = False
    signature_changed = False

    while loop.time() < deadline:
        await asyncio.sleep(0.25)
        current_signature = _jarvis_media_signature(hass.states.get(media_player_id))
        now = loop.time()

        if current_signature != baseline_signature:
            signature_changed = True

        current_state = current_signature[0]
        if current_state in {"playing", "buffering"}:
            if baseline_state not in {"playing", "buffering"} or signature_changed:
                playback_seen = True

        # Never restore the previous volume or clear the panel before the
        # conservative speech estimate has elapsed. This is essential for Sonos
        # announcements whose state briefly returns to the baseline while audio
        # is still coming from the speaker.
        if now < minimum_finish_at:
            continue

        if playback_seen:
            if baseline_state in {"playing", "paused", "buffering"}:
                if current_signature == baseline_signature:
                    break
            elif current_state not in {"playing", "buffering"}:
                break
        else:
            # Some Sonos announcement playback is not represented by a durable
            # state transition. Once the minimum speech duration has elapsed,
            # the estimate is the safest completion signal available.
            break

    if previous_volume is not None:
        try:
            await hass.services.async_call(
                "media_player",
                "volume_set",
                {"entity_id": media_player_id, "volume_level": previous_volume},
                blocking=True,
            )
        except Exception as exc:
            _LOGGER.warning("Could not restore %s volume after JARVIS: %s", media_player_id, exc)

    await _async_panel_playback_update(
        coordinator,
        request_id,
        "finished",
        media_player_id=media_player_id,
        tts_entity_id=tts_entity_id,
        response_hold_seconds=response_hold_seconds,
    )


async def _async_play_jarvis_through_home_assistant(
    hass: HomeAssistant,
    coordinator: Any,
    result: dict[str, Any],
    call_data: dict[str, Any],
) -> dict[str, Any]:
    """Use Home Assistant's native tts.speak action instead of panel-side audio."""
    request = result.get("speechRequest") if isinstance(result.get("speechRequest"), dict) else {}
    message = str(request.get("message") or result.get("spokenResponse") or result.get("response") or "").strip()
    if not message:
        raise HomeAssistantError("The thermostat did not return text to speak.")

    if request.get("enabled") is False:
        await _async_panel_playback_update(
            coordinator,
            int(result.get("requestId") or 0),
            "finished",
            response_hold_seconds=float(request.get("responseHoldSeconds") or 0.0),
        )
        return {
            "ttsPath": "disabled_by_panel",
            "speechPlayed": False,
            "speechDelegated": False,
            "speechSkipped": True,
        }

    tts_entity_id = str(call_data.get(ATTR_TTS_ENTITY_ID) or request.get("ttsEntityId") or "tts.home_assistant_cloud").strip()
    media_player_id = str(call_data.get(ATTR_MEDIA_PLAYER_ID) or request.get("mediaPlayerId") or "").strip()
    if not tts_entity_id.startswith("tts."):
        raise ServiceValidationError("The JARVIS TTS entity must be a tts.* entity.")
    if not media_player_id.startswith("media_player."):
        raise ServiceValidationError("Select a media_player.* entity for JARVIS announcements.")

    language = str(call_data.get(ATTR_LANGUAGE) or request.get("language") or "en-US").strip().replace("_", "-") or "en-US"
    if language.lower() == "en":
        language = "en-US"
    voice = str(request.get("voice") or "").strip()
    if "home_assistant_cloud" in tts_entity_id.lower() and not voice:
        voice = "JennyNeural"

    raw_volume = call_data.get(ATTR_ANNOUNCEMENT_VOLUME_PERCENT, request.get("announcementVolumePercent", DEFAULT_JARVIS_VOLUME_PERCENT))
    try:
        volume_percent = max(1, min(100, int(round(float(raw_volume)))))
    except (TypeError, ValueError):
        volume_percent = DEFAULT_JARVIS_VOLUME_PERCENT
    try:
        response_hold_seconds = max(0.0, min(15.0, float(request.get("responseHoldSeconds") or 0.0)))
    except (TypeError, ValueError):
        response_hold_seconds = 0.0

    media_state = hass.states.get(media_player_id)
    baseline_signature = _jarvis_media_signature(media_state)
    previous_volume: float | None = None
    if media_state is not None:
        try:
            previous_volume = float(media_state.attributes.get("volume_level"))
        except (TypeError, ValueError):
            previous_volume = None

    try:
        await hass.services.async_call(
            "media_player",
            "volume_set",
            {"entity_id": media_player_id, "volume_level": volume_percent / 100.0},
            blocking=True,
        )

        # Sonos can report the new volume before its amplifier has applied it.
        # Give the player a brief settling period so the first words are spoken
        # at the configured JARVIS announcement volume.
        await asyncio.sleep(JARVIS_VOLUME_SETTLE_SECONDS)

        estimated_seconds = _jarvis_estimated_speech_seconds(message)
        await _async_panel_playback_update(
            coordinator,
            int(result.get("requestId") or 0),
            "started",
            media_player_id=media_player_id,
            tts_entity_id=tts_entity_id,
            estimated_seconds=estimated_seconds,
            response_hold_seconds=response_hold_seconds,
        )

        service_data: dict[str, Any] = {
            "media_player_entity_id": media_player_id,
            "message": message,
            "language": language,
            "cache": False,
        }
        if voice:
            service_data["options"] = {"voice": voice}
        await hass.services.async_call(
            "tts",
            "speak",
            service_data,
            target={"entity_id": tts_entity_id},
            blocking=True,
        )
    except Exception as exc:
        if previous_volume is not None:
            try:
                await hass.services.async_call(
                    "media_player",
                    "volume_set",
                    {"entity_id": media_player_id, "volume_level": previous_volume},
                    blocking=True,
                )
            except Exception:
                pass
        await _async_panel_playback_update(
            coordinator,
            int(result.get("requestId") or 0),
            "failed",
            media_player_id=media_player_id,
            tts_entity_id=tts_entity_id,
            response_hold_seconds=response_hold_seconds,
            error=str(exc),
        )
        raise HomeAssistantError(f"Home Assistant could not play the JARVIS response: {exc}") from exc

    hass.async_create_task(
        _async_finish_jarvis_playback(
            hass,
            coordinator,
            request_id=int(result.get("requestId") or 0),
            media_player_id=media_player_id,
            tts_entity_id=tts_entity_id,
            baseline_signature=baseline_signature,
            previous_volume=previous_volume,
            estimated_seconds=estimated_seconds,
            response_hold_seconds=response_hold_seconds,
        ),
        name="IHA JARVIS playback cleanup",
    )
    return {
        "ttsEntityId": tts_entity_id,
        "mediaPlayerId": media_player_id,
        "ttsVoice": voice,
        "ttsLanguage": language,
        "announcementVolumePercent": volume_percent,
        "ttsPath": "home_assistant_native",
        "speechPlayed": True,
        "speechDelegated": True,
    }


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Register IHA actions and the shared JARVIS knowledge store."""
    domain_data = hass.data.setdefault(DOMAIN, {})
    volume_store = JarvisVolumeStore(hass)
    await volume_store.async_load()
    await volume_store.async_prepare_entries(hass.config_entries.async_entries(DOMAIN))
    domain_data[DATA_JARVIS_VOLUME_STORE] = volume_store

    knowledge = JarvisKnowledgeStore(hass)
    await knowledge.async_load()
    domain_data[DATA_JARVIS_KNOWLEDGE] = knowledge

    async def async_remember_knowledge(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_remember(
            key=str(call.data[ATTR_KEY]),
            entity_id=str(call.data[ATTR_ENTITY_ID]),
            attribute=str(call.data.get(ATTR_ATTRIBUTE) or ""),
            display_name=str(call.data.get(ATTR_DISPLAY_NAME) or ""),
            category=str(call.data.get(ATTR_CATEGORY) or "temperature"),
            inside=call.data.get(ATTR_INSIDE),
            aliases=[str(value) for value in call.data.get(ATTR_ALIASES, [])],
        )
        return result if call.return_response else None

    async def async_forget_knowledge(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_forget(str(call.data[ATTR_KEY]))
        return result if call.return_response else None

    async def async_get_knowledge(call: ServiceCall) -> ServiceResponse:
        inside = call.data.get(ATTR_INSIDE) if ATTR_INSIDE in call.data else None
        return await knowledge.async_get(
            keys=[str(value) for value in call.data.get(ATTR_KEYS, [])],
            category=str(call.data.get(ATTR_CATEGORY) or ""),
            inside=inside,
        )

    hass.services.async_register(
        DOMAIN,
        SERVICE_REMEMBER_KNOWLEDGE,
        async_remember_knowledge,
        schema=SERVICE_REMEMBER_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_FORGET_KNOWLEDGE,
        async_forget_knowledge,
        schema=SERVICE_FORGET_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_GET_KNOWLEDGE,
        async_get_knowledge,
        schema=SERVICE_GET_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.ONLY,
    )

    domain_data[DATA_JARVIS_PROFILE] = knowledge

    async def async_get_jarvis_profile(call: ServiceCall) -> ServiceResponse:
        return await knowledge.async_get_profile()

    async def async_set_jarvis_profile(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_set_profile(**dict(call.data))
        return result if call.return_response else None

    hass.services.async_register(
        DOMAIN,
        SERVICE_GET_JARVIS_PROFILE,
        async_get_jarvis_profile,
        schema=SERVICE_GET_JARVIS_PROFILE_SCHEMA,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_SET_JARVIS_PROFILE,
        async_set_jarvis_profile,
        schema=SERVICE_SET_JARVIS_PROFILE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )

    def coordinator_for_call(call: ServiceCall) -> Any:
        """Return the explicitly selected, loaded IHA coordinator."""
        entry_id = str(
            call.data.get(ATTR_CONFIG_ENTRY)
            or call.data.get(ATTR_CONFIG_ENTRY_ID)
            or ""
        ).strip()
        if not entry_id:
            raise ServiceValidationError("Select the IHA thermostat that should handle the request.")
        entry = hass.config_entries.async_get_entry(entry_id)
        if entry is None or entry.domain != DOMAIN:
            raise ServiceValidationError("The selected IHA thermostat entry was not found.")
        if entry.state is not ConfigEntryState.LOADED:
            raise ServiceValidationError(
                f"The selected IHA thermostat is not loaded (current state: {entry.state})."
            )
        coordinator = hass.data.get(DOMAIN, {}).get(entry_id)
        if coordinator is None:
            raise ServiceValidationError("The selected IHA thermostat is not ready.")
        return coordinator

    async def async_ask_jarvis(call: ServiceCall) -> ServiceResponse | None:
        """Send a typed command to one explicitly selected IHA thermostat."""
        coordinator = coordinator_for_call(call)

        requested_speak = bool(call.data[ATTR_SPEAK])
        payload: dict[str, Any] = {
            "text": str(call.data[ATTR_COMMAND]).strip(),
            "speak": False,
            "externalSpeech": requested_speak,
            "newConversation": bool(call.data[ATTR_NEW_CONVERSATION]),
            "funMode": bool(call.data[ATTR_FUN_MODE]),
            "playfulReplies": bool(call.data[ATTR_PLAYFUL_REPLIES]),
            "language": str(call.data[ATTR_LANGUAGE]).strip() or "en",
        }
        optional_fields = (
            (ATTR_AGENT_ID, "agentId", "conversation"),
            (ATTR_TTS_ENTITY_ID, "ttsEntityId", "tts"),
            (ATTR_MEDIA_PLAYER_ID, "mediaPlayerId", "media_player"),
        )
        for service_key, payload_key, domain in optional_fields:
            value = _optional_text(call.data, service_key)
            if not value:
                continue
            if not value.startswith(f"{domain}."):
                raise ServiceValidationError(
                    f"{service_key} must be a {domain}. entity ID or blank."
                )
            payload[payload_key] = value

        try:
            result = await coordinator.api.assistant_process(payload)
            if requested_speak:
                result.update(
                    await _async_play_jarvis_through_home_assistant(
                        hass, coordinator, result, dict(call.data)
                    )
                )
        except Exception as exc:
            raise HomeAssistantError(f"Could not run the thermostat voice assistant: {exc}") from exc

        if call.return_response:
            return result
        return None

    hass.services.async_register(
        DOMAIN,
        SERVICE_ASK_JARVIS,
        async_ask_jarvis,
        schema=SERVICE_ASK_JARVIS_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )

    async def async_jarvis_announcement(call: ServiceCall) -> ServiceResponse | None:
        """Speak supplied automation copy exactly, without conversation processing."""
        coordinator = coordinator_for_call(call)
        payload: dict[str, Any] = {
            "text": str(call.data[ATTR_MESSAGE]).strip(),
            "speak": False,
            "externalSpeech": True,
            "force": True,
            "announcementOnly": True,
            "newConversation": False,
            "funMode": False,
            "playfulReplies": False,
            "language": str(call.data[ATTR_LANGUAGE]).strip() or "en",
        }
        optional_fields = (
            (ATTR_TTS_ENTITY_ID, "ttsEntityId", "tts"),
            (ATTR_MEDIA_PLAYER_ID, "mediaPlayerId", "media_player"),
        )
        for service_key, payload_key, domain in optional_fields:
            value = _optional_text(call.data, service_key)
            if not value:
                continue
            if not value.startswith(f"{domain}."):
                raise ServiceValidationError(
                    f"{service_key} must be a {domain}. entity ID or blank."
                )
            payload[payload_key] = value
        if ATTR_ANNOUNCEMENT_VOLUME_PERCENT in call.data:
            payload["announcementVolumePercent"] = int(
                call.data[ATTR_ANNOUNCEMENT_VOLUME_PERCENT]
            )

        try:
            result = await coordinator.api.assistant_process(payload)
            result.update(
                await _async_play_jarvis_through_home_assistant(
                    hass, coordinator, result, dict(call.data)
                )
            )
        except Exception as exc:
            raise HomeAssistantError(f"Could not play the JARVIS announcement: {exc}") from exc

        if call.return_response:
            return result
        return None

    hass.services.async_register(
        DOMAIN,
        SERVICE_JARVIS_ANNOUNCEMENT,
        async_jarvis_announcement,
        schema=SERVICE_JARVIS_ANNOUNCEMENT_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    return True

PLATFORMS: list[Platform] = [
    Platform.CLIMATE,
    Platform.SENSOR,
    Platform.BINARY_SENSOR,
    Platform.BUTTON,
    Platform.SWITCH,
    Platform.SELECT,
    Platform.UPDATE,
]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up IHA from a config entry."""
    session = async_get_clientsession(hass)
    api = IhaApi(session, entry.data[CONF_HOST], entry.data.get(CONF_PORT, 8080))
    coordinator = IhaCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    # Hardware telemetry uses a separate read-only coordinator. This preserves
    # the existing 10-second climate polling and command-echo protections while
    # allowing motion to update at its independent 1/3/6-second check interval.
    hardware_coordinator = IhaHardwareCoordinator(hass, api)
    coordinator.hardware_coordinator = hardware_coordinator
    try:
        await hardware_coordinator.async_config_entry_first_refresh()
    except ConfigEntryNotReady as exc:
        # Keep the established climate entity online if Home Assistant is updated
        # before the matching panel build. Hardware entities will remain
        # unavailable and begin polling when their coordinator listeners attach.
        _LOGGER.warning("IHA hardware telemetry is not available yet: %s", exc)

    # Software availability is intentionally separate from the 10-second
    # thermostat poll. It checks GitHub every 15 minutes and switches to a
    # five-second local status poll only while an update is running.
    update_coordinator = IhaUpdateCoordinator(hass, api)
    coordinator.update_coordinator = update_coordinator
    try:
        await update_coordinator.async_config_entry_first_refresh()
    except ConfigEntryNotReady as exc:
        # Keep Software available from the already-live thermostat data even if
        # the dedicated status endpoint has a transient startup failure. The
        # coordinator will retry after its listeners are attached.
        panel_data = coordinator.data or {}
        climate_data = panel_data.get("climate") or panel_data.get("thermostat")
        climate_data = climate_data if isinstance(climate_data, dict) else panel_data
        installed = str(
            climate_data.get("swVersion")
            or climate_data.get("sw_version")
            or panel_data.get("swVersion")
            or panel_data.get("sw_version")
            or "unknown"
        ).strip()
        fallback_update_data = {
            "ok": True,
            "installedVersion": installed,
            "latestVersion": installed,
            "updateAvailable": False,
            "inProgress": False,
            "phase": "status-retry",
            "message": "Software status will retry automatically.",
            "connectionError": str(exc),
        }
        update_coordinator.set_fallback_data(fallback_update_data)
        _LOGGER.warning("IHA software update status is not available yet: %s", exc)

    def _current_panel_data() -> dict:
        data = coordinator.data or {}
        climate = data.get("climate") or data.get("thermostat")
        return climate if isinstance(climate, dict) else data

    def _panel_serial() -> str:
        data = coordinator.data or {}
        climate = _current_panel_data()
        # Prefer the live panel-provided id over the saved entry id. This lets
        # existing entries recover from old builds that used a cloned
        # /etc/machine-id as the serial.
        return str(
            data.get("serial")
            or data.get("unique_id")
            or data.get("id")
            or data.get("hardware_id")
            or data.get("mac_address")
            or climate.get("serial")
            or climate.get("unique_id")
            or climate.get("id")
            or climate.get("hardware_id")
            or climate.get("mac_address")
            or entry.data.get(CONF_SERIAL)
            or entry.unique_id
            or f"{api.host}:{api.port}"
        ).strip()

    def _sync_entry_metadata() -> None:
        data = coordinator.data or {}
        climate = _current_panel_data()
        name = str(climate.get("name") or data.get("name") or DEFAULT_NAME).strip() or DEFAULT_NAME
        serial = _panel_serial()
        updates: dict[str, object] = {}
        if serial and entry.data.get(CONF_SERIAL) != serial:
            updates[CONF_SERIAL] = serial
        update_kwargs: dict[str, object] = {}
        if updates:
            update_kwargs["data"] = {**entry.data, **updates}
        if serial and entry.unique_id != serial:
            update_kwargs["unique_id"] = serial
        if entry.title != name:
            update_kwargs["title"] = name
        if update_kwargs:
            hass.config_entries.async_update_entry(entry, **update_kwargs)

    _sync_entry_metadata()
    entry.async_on_unload(coordinator.async_add_listener(_sync_entry_metadata))
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    volume_store = hass.data.get(DOMAIN, {}).get(DATA_JARVIS_VOLUME_STORE)
    if isinstance(volume_store, JarvisVolumeStore):
        await volume_store.async_update_from_panel(
            entry,
            coordinator.data,
            source_available=bool(coordinator.last_update_success),
        )

        def _sync_jarvis_volume() -> None:
            hass.async_create_task(
                volume_store.async_update_from_panel(
                    entry,
                    coordinator.data,
                    source_available=bool(coordinator.last_update_success),
                )
            )

        entry.async_on_unload(coordinator.async_add_listener(_sync_jarvis_volume))

    # Pre-load platform modules in Home Assistant's executor. Home Assistant
    # imports modules using importlib, which can touch disk and block the event
    # loop if a platform is first imported during setup forwarding.
    for platform in PLATFORMS:
        await hass.async_add_executor_job(importlib.import_module, f"{__name__}.{platform.value}")
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry while retaining its last usable JARVIS volume."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id, None)
        volume_store = hass.data.get(DOMAIN, {}).get(DATA_JARVIS_VOLUME_STORE)
        if isinstance(volume_store, JarvisVolumeStore):
            await volume_store.async_mark_unavailable(entry)
    return unload_ok


async def async_remove_entry(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Remove cached JARVIS volume data when an IHA panel is deleted."""
    volume_store = hass.data.get(DOMAIN, {}).get(DATA_JARVIS_VOLUME_STORE)
    if isinstance(volume_store, JarvisVolumeStore):
        await volume_store.async_remove(entry)
