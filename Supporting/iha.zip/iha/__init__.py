"""IHA integration."""

from __future__ import annotations

import importlib
import logging
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry, ConfigEntryState
from homeassistant.const import CONF_HOST, CONF_PORT, Platform
from homeassistant.core import HomeAssistant, ServiceCall, ServiceResponse, SupportsResponse
from homeassistant.exceptions import ConfigEntryNotReady, HomeAssistantError, ServiceValidationError
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.typing import ConfigType

from .api import IhaApi
from .const import (
    ATTR_AGENT_ID,
    ATTR_ALIASES,
    ATTR_ATTRIBUTE,
    ATTR_CATEGORY,
    ATTR_COMMAND,
    ATTR_DISPLAY_NAME,
    ATTR_ENTITY_ID,
    ATTR_CONFIG_ENTRY,
    ATTR_CONFIG_ENTRY_ID,
    ATTR_FUN_MODE,
    ATTR_INSIDE,
    ATTR_KEY,
    ATTR_KEYS,
    ATTR_LANGUAGE,
    ATTR_MEDIA_PLAYER_ID,
    ATTR_NEW_CONVERSATION,
    ATTR_PLAYFUL_REPLIES,
    ATTR_SPEAK,
    ATTR_TTS_ENTITY_ID,
    ATTR_ROUTING_MODE,
    ATTR_LOCAL_AGENT_ID,
    ATTR_CLOUD_AGENT_ID,
    ATTR_TTS_POLICY,
    ATTR_LOCAL_TTS_ENTITY_ID,
    ATTR_ADDRESS,
    ATTR_HUMOR_LEVEL,
    ATTR_USE_TITLE,
    CONF_SERIAL,
    DATA_JARVIS_KNOWLEDGE,
    DATA_JARVIS_PROFILE,
    DEFAULT_NAME,
    DOMAIN,
    SERVICE_ASK_JARVIS,
    SERVICE_FORGET_KNOWLEDGE,
    SERVICE_GET_KNOWLEDGE,
    SERVICE_REMEMBER_KNOWLEDGE,
    SERVICE_GET_JARVIS_PROFILE,
    SERVICE_SET_JARVIS_PROFILE,
)
from .coordinator import IhaCoordinator, IhaHardwareCoordinator, IhaUpdateCoordinator
from .knowledge import JarvisKnowledgeStore

_LOGGER = logging.getLogger(__name__)

SERVICE_REMEMBER_KNOWLEDGE_SCHEMA = vol.Schema(
    {
        vol.Required(ATTR_KEY): vol.All(cv.string, vol.Length(min=1, max=120)),
        vol.Required(ATTR_ENTITY_ID): cv.entity_id,
        vol.Optional(ATTR_ATTRIBUTE, default=""): vol.All(cv.string, vol.Length(max=96)),
        vol.Optional(ATTR_DISPLAY_NAME, default=""): vol.All(cv.string, vol.Length(max=120)),
        vol.Optional(ATTR_CATEGORY, default="temperature"): vol.All(cv.string, vol.Length(min=1, max=64)),
        vol.Optional(ATTR_INSIDE): cv.boolean,
        vol.Optional(ATTR_ALIASES): vol.All(cv.ensure_list, [vol.All(cv.string, vol.Length(min=1, max=96))]),
    }
)

SERVICE_FORGET_KNOWLEDGE_SCHEMA = vol.Schema(
    {vol.Required(ATTR_KEY): vol.All(cv.string, vol.Length(min=1, max=120))}
)

SERVICE_GET_KNOWLEDGE_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_KEYS): vol.All(cv.ensure_list, [vol.All(cv.string, vol.Length(min=1, max=120))]),
        vol.Optional(ATTR_CATEGORY, default=""): vol.All(cv.string, vol.Length(max=64)),
        vol.Optional(ATTR_INSIDE): cv.boolean,
    }
)

SERVICE_GET_JARVIS_PROFILE_SCHEMA = vol.Schema({})

SERVICE_SET_JARVIS_PROFILE_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_ROUTING_MODE): vol.In(["hybrid", "local_only", "cloud_only"]),
        vol.Optional(ATTR_LOCAL_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_CLOUD_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_TTS_POLICY): vol.In(["hybrid", "local_only", "premium_only"]),
        vol.Optional(ATTR_LOCAL_TTS_ENTITY_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_ADDRESS): vol.All(cv.string, vol.Length(min=1, max=32)),
        vol.Optional(ATTR_HUMOR_LEVEL): vol.All(vol.Coerce(int), vol.Range(min=0, max=2)),
        vol.Optional(ATTR_USE_TITLE): cv.boolean,
    }
)

SERVICE_ASK_JARVIS_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_CONFIG_ENTRY): cv.string,
        vol.Optional(ATTR_CONFIG_ENTRY_ID): cv.string,
        vol.Required(ATTR_COMMAND): vol.All(cv.string, vol.Length(min=1, max=1200)),
        vol.Optional(ATTR_SPEAK, default=True): cv.boolean,
        vol.Optional(ATTR_NEW_CONVERSATION, default=True): cv.boolean,
        vol.Optional(ATTR_FUN_MODE, default=False): cv.boolean,
        vol.Optional(ATTR_PLAYFUL_REPLIES, default=True): cv.boolean,
        vol.Optional(ATTR_LANGUAGE, default="en"): vol.All(cv.string, vol.Length(min=1, max=16)),
        vol.Optional(ATTR_AGENT_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_TTS_ENTITY_ID): vol.Any("", None, cv.entity_id),
        vol.Optional(ATTR_MEDIA_PLAYER_ID): vol.Any("", None, cv.entity_id),
    }
)


def _optional_text(data: dict[str, Any], key: str) -> str:
    """Return a trimmed optional service field."""
    return str(data.get(key) or "").strip()


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Register IHA actions and the shared JARVIS knowledge store."""
    domain_data = hass.data.setdefault(DOMAIN, {})
    knowledge = JarvisKnowledgeStore(hass)
    await knowledge.async_load()
    domain_data[DATA_JARVIS_KNOWLEDGE] = knowledge

    async def async_remember_knowledge(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_remember(
            key=str(call.data[ATTR_KEY]),
            entity_id=str(call.data[ATTR_ENTITY_ID]),
            attribute=str(call.data.get(ATTR_ATTRIBUTE) or ""),
            display_name=str(call.data.get(ATTR_DISPLAY_NAME) or ""),
            category=str(call.data.get(ATTR_CATEGORY) or "temperature"),
            inside=call.data.get(ATTR_INSIDE),
            aliases=[str(value) for value in call.data.get(ATTR_ALIASES, [])],
        )
        return result if call.return_response else None

    async def async_forget_knowledge(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_forget(str(call.data[ATTR_KEY]))
        return result if call.return_response else None

    async def async_get_knowledge(call: ServiceCall) -> ServiceResponse:
        inside = call.data.get(ATTR_INSIDE) if ATTR_INSIDE in call.data else None
        return await knowledge.async_get(
            keys=[str(value) for value in call.data.get(ATTR_KEYS, [])],
            category=str(call.data.get(ATTR_CATEGORY) or ""),
            inside=inside,
        )

    hass.services.async_register(
        DOMAIN,
        SERVICE_REMEMBER_KNOWLEDGE,
        async_remember_knowledge,
        schema=SERVICE_REMEMBER_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_FORGET_KNOWLEDGE,
        async_forget_knowledge,
        schema=SERVICE_FORGET_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_GET_KNOWLEDGE,
        async_get_knowledge,
        schema=SERVICE_GET_KNOWLEDGE_SCHEMA,
        supports_response=SupportsResponse.ONLY,
    )

    domain_data[DATA_JARVIS_PROFILE] = knowledge

    async def async_get_jarvis_profile(call: ServiceCall) -> ServiceResponse:
        return await knowledge.async_get_profile()

    async def async_set_jarvis_profile(call: ServiceCall) -> ServiceResponse | None:
        result = await knowledge.async_set_profile(**dict(call.data))
        return result if call.return_response else None

    hass.services.async_register(
        DOMAIN,
        SERVICE_GET_JARVIS_PROFILE,
        async_get_jarvis_profile,
        schema=SERVICE_GET_JARVIS_PROFILE_SCHEMA,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_SET_JARVIS_PROFILE,
        async_set_jarvis_profile,
        schema=SERVICE_SET_JARVIS_PROFILE_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )

    async def async_ask_jarvis(call: ServiceCall) -> ServiceResponse | None:
        """Send a typed command to one explicitly selected IHA thermostat."""
        entry_id = str(
            call.data.get(ATTR_CONFIG_ENTRY)
            or call.data.get(ATTR_CONFIG_ENTRY_ID)
            or ""
        ).strip()
        if not entry_id:
            raise ServiceValidationError("Select the IHA thermostat that should handle the command.")
        entry = hass.config_entries.async_get_entry(entry_id)
        if entry is None or entry.domain != DOMAIN:
            raise ServiceValidationError("The selected IHA thermostat entry was not found.")
        if entry.state is not ConfigEntryState.LOADED:
            raise ServiceValidationError(
                f"The selected IHA thermostat is not loaded (current state: {entry.state})."
            )

        coordinator = hass.data.get(DOMAIN, {}).get(entry_id)
        if coordinator is None:
            raise ServiceValidationError("The selected IHA thermostat is not ready.")

        payload: dict[str, Any] = {
            "text": str(call.data[ATTR_COMMAND]).strip(),
            "speak": bool(call.data[ATTR_SPEAK]),
            "newConversation": bool(call.data[ATTR_NEW_CONVERSATION]),
            "funMode": bool(call.data[ATTR_FUN_MODE]),
            "playfulReplies": bool(call.data[ATTR_PLAYFUL_REPLIES]),
            "language": str(call.data[ATTR_LANGUAGE]).strip() or "en",
        }
        optional_fields = (
            (ATTR_AGENT_ID, "agentId", "conversation"),
            (ATTR_TTS_ENTITY_ID, "ttsEntityId", "tts"),
            (ATTR_MEDIA_PLAYER_ID, "mediaPlayerId", "media_player"),
        )
        for service_key, payload_key, domain in optional_fields:
            value = _optional_text(call.data, service_key)
            if not value:
                continue
            if not value.startswith(f"{domain}."):
                raise ServiceValidationError(
                    f"{service_key} must be a {domain}. entity ID or blank."
                )
            payload[payload_key] = value

        try:
            result = await coordinator.api.assistant_process(payload)
        except Exception as exc:
            raise HomeAssistantError(f"Could not run the thermostat voice assistant: {exc}") from exc

        if call.return_response:
            return result
        return None

    hass.services.async_register(
        DOMAIN,
        SERVICE_ASK_JARVIS,
        async_ask_jarvis,
        schema=SERVICE_ASK_JARVIS_SCHEMA,
        supports_response=SupportsResponse.OPTIONAL,
    )
    return True

PLATFORMS: list[Platform] = [
    Platform.CLIMATE,
    Platform.SENSOR,
    Platform.BINARY_SENSOR,
    Platform.BUTTON,
    Platform.SELECT,
    Platform.UPDATE,
]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up IHA from a config entry."""
    session = async_get_clientsession(hass)
    api = IhaApi(session, entry.data[CONF_HOST], entry.data.get(CONF_PORT, 8080))
    coordinator = IhaCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    # Hardware telemetry uses a separate read-only coordinator. This preserves
    # the existing 10-second climate polling and command-echo protections while
    # allowing motion to update at its independent 1/3/6-second check interval.
    hardware_coordinator = IhaHardwareCoordinator(hass, api)
    coordinator.hardware_coordinator = hardware_coordinator
    try:
        await hardware_coordinator.async_config_entry_first_refresh()
    except ConfigEntryNotReady as exc:
        # Keep the established climate entity online if Home Assistant is updated
        # before the matching panel build. Hardware entities will remain
        # unavailable and begin polling when their coordinator listeners attach.
        _LOGGER.warning("IHA hardware telemetry is not available yet: %s", exc)

    # Software availability is intentionally separate from the 10-second
    # thermostat poll. It checks GitHub every 15 minutes and switches to a
    # five-second local status poll only while an update is running.
    update_coordinator = IhaUpdateCoordinator(hass, api)
    coordinator.update_coordinator = update_coordinator
    try:
        await update_coordinator.async_config_entry_first_refresh()
    except ConfigEntryNotReady as exc:
        # Keep Software available from the already-live thermostat data even if
        # the dedicated status endpoint has a transient startup failure. The
        # coordinator will retry after its listeners are attached.
        panel_data = coordinator.data or {}
        climate_data = panel_data.get("climate") or panel_data.get("thermostat")
        climate_data = climate_data if isinstance(climate_data, dict) else panel_data
        installed = str(
            climate_data.get("swVersion")
            or climate_data.get("sw_version")
            or panel_data.get("swVersion")
            or panel_data.get("sw_version")
            or "unknown"
        ).strip()
        fallback_update_data = {
            "ok": True,
            "installedVersion": installed,
            "latestVersion": installed,
            "updateAvailable": False,
            "inProgress": False,
            "phase": "status-retry",
            "message": "Software status will retry automatically.",
            "connectionError": str(exc),
        }
        update_coordinator.set_fallback_data(fallback_update_data)
        _LOGGER.warning("IHA software update status is not available yet: %s", exc)

    def _current_panel_data() -> dict:
        data = coordinator.data or {}
        climate = data.get("climate") or data.get("thermostat")
        return climate if isinstance(climate, dict) else data

    def _panel_serial() -> str:
        data = coordinator.data or {}
        climate = _current_panel_data()
        # Prefer the live panel-provided id over the saved entry id. This lets
        # existing entries recover from old builds that used a cloned
        # /etc/machine-id as the serial.
        return str(
            data.get("serial")
            or data.get("unique_id")
            or data.get("id")
            or data.get("hardware_id")
            or data.get("mac_address")
            or climate.get("serial")
            or climate.get("unique_id")
            or climate.get("id")
            or climate.get("hardware_id")
            or climate.get("mac_address")
            or entry.data.get(CONF_SERIAL)
            or entry.unique_id
            or f"{api.host}:{api.port}"
        ).strip()

    def _sync_entry_metadata() -> None:
        data = coordinator.data or {}
        climate = _current_panel_data()
        name = str(climate.get("name") or data.get("name") or DEFAULT_NAME).strip() or DEFAULT_NAME
        serial = _panel_serial()
        updates: dict[str, object] = {}
        if serial and entry.data.get(CONF_SERIAL) != serial:
            updates[CONF_SERIAL] = serial
        update_kwargs: dict[str, object] = {}
        if updates:
            update_kwargs["data"] = {**entry.data, **updates}
        if serial and entry.unique_id != serial:
            update_kwargs["unique_id"] = serial
        if entry.title != name:
            update_kwargs["title"] = name
        if update_kwargs:
            hass.config_entries.async_update_entry(entry, **update_kwargs)

    _sync_entry_metadata()
    entry.async_on_unload(coordinator.async_add_listener(_sync_entry_metadata))
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    # Pre-load platform modules in Home Assistant's executor. Home Assistant
    # imports modules using importlib, which can touch disk and block the event
    # loop if a platform is first imported during setup forwarding.
    for platform in PLATFORMS:
        await hass.async_add_executor_job(importlib.import_module, f"{__name__}.{platform.value}")
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unload_ok
