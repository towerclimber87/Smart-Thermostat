"""Switch platform for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaCoordinatorEntity


def _portal_data(data: object) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    raw = data.get("configWebPortal") or data.get("config_web_portal")
    if isinstance(raw, dict):
        return raw
    climate = data.get("climate") or data.get("thermostat")
    if isinstance(climate, dict):
        raw = climate.get("configWebPortal") or climate.get("config_web_portal")
        if isinstance(raw, dict):
            return raw
    return {}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([IhaBackupPortalSwitch(entry, coordinator)])


class IhaBackupPortalSwitch(IhaCoordinatorEntity, SwitchEntity):
    """Control the thermostat's temporary Backup / Settings web portal."""

    _attr_name = "Backup Portal"
    _attr_icon = "mdi:backup-restore"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(entry, coordinator)
        self._attr_unique_id = f"{self._serial}_backup_portal"

    @property
    def is_on(self) -> bool:
        return bool(_portal_data(self.coordinator.data).get("active"))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        portal = _portal_data(self.coordinator.data)
        return {
            "backup_url": portal.get("url"),
            "timeout_seconds": portal.get("timeoutSeconds"),
            "remaining_seconds": portal.get("remainingSeconds"),
        }

    async def async_turn_on(self, **kwargs: Any) -> None:
        try:
            await self.coordinator.api.open_backup()
            await self.coordinator.async_request_refresh()
        except Exception as exc:
            raise HomeAssistantError(f"Could not open the thermostat Backup portal: {exc}") from exc

    async def async_turn_off(self, **kwargs: Any) -> None:
        try:
            await self.coordinator.api.close_backup()
            await self.coordinator.async_request_refresh()
        except Exception as exc:
            raise HomeAssistantError(f"Could not close the thermostat Backup portal: {exc}") from exc
