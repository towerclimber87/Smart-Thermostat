"""Constants for the IHA integration."""

from __future__ import annotations

from homeassistant.const import CONF_HOST, CONF_PORT

DOMAIN = "iha"
DEFAULT_PORT = 8080
DEFAULT_NAME = "IHA"
CONF_SERIAL = "serial"
CONF_API_PATH = "api_path"
