"""Constants for the IHA integration."""

from __future__ import annotations

from homeassistant.const import CONF_HOST, CONF_PORT

DOMAIN = "iha"
DEFAULT_PORT = 8080
DEFAULT_NAME = "IHA"
CONF_SERIAL = "serial"
CONF_API_PATH = "api_path"

SERVICE_ASK_JARVIS = "ask_jarvis"
ATTR_CONFIG_ENTRY = "config_entry"
ATTR_CONFIG_ENTRY_ID = "config_entry_id"  # Legacy alias for 10.7.0 callers.
ATTR_COMMAND = "command"
ATTR_SPEAK = "speak"
ATTR_NEW_CONVERSATION = "new_conversation"
ATTR_FUN_MODE = "fun_mode"
ATTR_PLAYFUL_REPLIES = "playful_replies"
ATTR_LANGUAGE = "language"
ATTR_AGENT_ID = "agent_id"
ATTR_TTS_ENTITY_ID = "tts_entity_id"
ATTR_MEDIA_PLAYER_ID = "media_player_id"
