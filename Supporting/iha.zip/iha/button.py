"""Button platform for IHA."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaCoordinatorEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    if coordinator.update_coordinator is not None:
        async_add_entities([IhaCheckUpdatesButton(entry, coordinator)])


class IhaCheckUpdatesButton(IhaCoordinatorEntity, ButtonEntity):
    _attr_name = "Check for updates"
    _attr_icon = "mdi:update"

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(entry, coordinator)
        self._attr_unique_id = f"{self._serial}_check_updates"

    async def async_press(self) -> None:
        update = self.coordinator.update_coordinator
        if update is not None:
            await update.async_force_refresh_remote()
