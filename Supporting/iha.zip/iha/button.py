"""Button platform for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator, IhaUpdateCoordinator
from .entity import _current_panel_data, _panel_serial

PARALLEL_UPDATES = 0


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up IHA button entities."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    update_coordinator = panel_coordinator.update_coordinator
    if update_coordinator is None:
        return
    async_add_entities(
        [IhaCheckForUpdatesButton(update_coordinator, panel_coordinator, entry)]
    )


class IhaCheckForUpdatesButton(
    CoordinatorEntity[IhaUpdateCoordinator], ButtonEntity
):
    """Immediately check the thermostat's configured GitHub branch."""

    _attr_has_entity_name = True
    _attr_name = "Check for Updates"
    _attr_icon = "mdi:refresh"
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(
        self,
        coordinator: IhaUpdateCoordinator,
        panel_coordinator: IhaCoordinator,
        entry: ConfigEntry,
    ) -> None:
        super().__init__(coordinator)
        self.panel_coordinator = panel_coordinator
        self.entry = entry
        self.serial = _panel_serial(panel_coordinator, entry)
        self._attr_unique_id = f"{self.serial}_check_for_updates"

    @property
    def update_data(self) -> dict[str, Any]:
        """Return the latest software status payload."""
        return self.coordinator.data if isinstance(self.coordinator.data, dict) else {}

    @property
    def available(self) -> bool:
        """Allow checks whenever the panel is reachable and not installing."""
        return (
            not bool(self.update_data.get("inProgress"))
            and (
                bool(self.update_data)
                or self.panel_coordinator.has_recent_status
                or bool(self.panel_coordinator.data)
            )
        )

    @property
    def device_info(self) -> DeviceInfo:
        """Attach the button to the same thermostat device."""
        climate = _current_panel_data(self.panel_coordinator)
        data = self.panel_coordinator.data or {}
        return DeviceInfo(
            identifiers={(DOMAIN, self.serial)},
            name=climate.get("name") or data.get("name") or DEFAULT_NAME,
            manufacturer=climate.get("manufacturer")
            or data.get("manufacturer")
            or "IHA",
            model=climate.get("model") or data.get("model") or "Wall Thermostat",
            sw_version=(
                climate.get("swVersion")
                or climate.get("sw_version")
                or data.get("swVersion")
                or data.get("sw_version")
            ),
        )

    async def async_press(self) -> None:
        """Run an immediate GitHub availability check without installing."""
        try:
            await self.coordinator.async_check_for_updates()
        except Exception as exc:
            raise HomeAssistantError(f"Could not check for thermostat updates: {exc}") from exc
