"""Button platform for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaCoordinatorEntity, climate_data, panel_serial


def _schedule_entries(data: object) -> list[dict[str, Any]]:
    climate = climate_data(data)
    raw = climate.get("schedules")
    if not isinstance(raw, list) and isinstance(data, dict):
        raw = data.get("schedules")
    if not isinstance(raw, list):
        return []
    return [item for item in raw if isinstance(item, dict) and str(item.get("id") or "").strip()]


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]

    # Remove the retired one-way Open Backup button from existing installs.
    registry = er.async_get(hass)
    retired_entity_id = registry.async_get_entity_id(
        "button", DOMAIN, f"{panel_serial(entry, coordinator)}_open_backup"
    )
    if retired_entity_id is not None:
        registry.async_remove(retired_entity_id)

    base_entities: list[ButtonEntity] = []
    if coordinator.update_coordinator is not None:
        base_entities.extend([
            IhaCheckUpdatesButton(entry, coordinator),
            IhaForceSoftwareUpdateButton(entry, coordinator),
        ])
    if base_entities:
        async_add_entities(base_entities)

    known_schedule_ids: set[str] = set()

    @callback
    def async_discover_schedule_buttons() -> None:
        new_entities: list[ButtonEntity] = []
        for schedule in _schedule_entries(coordinator.data):
            schedule_id = str(schedule.get("id") or "").strip()
            if not schedule_id or schedule_id in known_schedule_ids:
                continue
            known_schedule_ids.add(schedule_id)
            new_entities.append(IhaScheduleButton(entry, coordinator, schedule_id))
        if new_entities:
            async_add_entities(new_entities)

    async_discover_schedule_buttons()
    entry.async_on_unload(coordinator.async_add_listener(async_discover_schedule_buttons))


class IhaCheckUpdatesButton(IhaCoordinatorEntity, ButtonEntity):
    _attr_name = "Check for updates"
    _attr_icon = "mdi:update"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(entry, coordinator)
        self._attr_unique_id = f"{self._serial}_check_updates"

    async def async_press(self) -> None:
        update = self.coordinator.update_coordinator
        if update is not None:
            await update.async_force_refresh_remote()


class IhaForceSoftwareUpdateButton(IhaCoordinatorEntity, ButtonEntity):
    _attr_name = "Force software update"
    _attr_icon = "mdi:download"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(entry, coordinator)
        self._attr_unique_id = f"{self._serial}_force_software_update"

    @property
    def available(self) -> bool:
        update = self.coordinator.update_coordinator
        if update is None or not super().available or not update.last_update_success:
            return False
        data = update.data if isinstance(update.data, dict) else {}
        return not bool(data.get("inProgress"))

    async def async_press(self) -> None:
        update = self.coordinator.update_coordinator
        if update is None:
            raise HomeAssistantError("Software update status is unavailable.")
        await update.api.install_update()
        await update.async_request_refresh()


class IhaScheduleButton(IhaCoordinatorEntity, ButtonEntity):
    _attr_icon = "mdi:calendar-play"

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator, schedule_id: str) -> None:
        super().__init__(entry, coordinator)
        self.schedule_id = schedule_id
        self._attr_unique_id = f"{self._serial}_schedule_{schedule_id}"

    def _schedule(self) -> dict[str, Any] | None:
        return next(
            (item for item in _schedule_entries(self.coordinator.data) if str(item.get("id") or "") == self.schedule_id),
            None,
        )

    @property
    def name(self) -> str:
        schedule = self._schedule() or {}
        schedule_name = str(schedule.get("name") or "Schedule").strip() or "Schedule"
        return f"Run {schedule_name}"

    @property
    def available(self) -> bool:
        return super().available and self._schedule() is not None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        schedule = self._schedule() or {}
        return {
            "schedule_id": self.schedule_id,
            "schedule_name": schedule.get("name"),
            "time": schedule.get("time"),
            "days": schedule.get("days") or [],
            "heat_setpoint": schedule.get("heatSetpoint"),
            "cool_setpoint": schedule.get("coolSetpoint"),
        }

    async def async_press(self) -> None:
        if self._schedule() is None:
            raise HomeAssistantError("This thermostat schedule no longer exists.")
        await self.coordinator.async_run_schedule(self.schedule_id)
