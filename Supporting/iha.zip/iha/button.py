"""Button platform for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator, IhaUpdateCoordinator
from .entity import _current_panel_data, _panel_serial

PARALLEL_UPDATES = 0


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up IHA button entities."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    update_coordinator = panel_coordinator.update_coordinator
    entities: list[ButtonEntity] = [
        IhaSyncNextChangeButton(panel_coordinator, entry),
        IhaArrivingSyncReceiverButton(panel_coordinator, entry),
    ]
    if update_coordinator is not None:
        entities.append(IhaCheckForUpdatesButton(update_coordinator, panel_coordinator, entry))
    async_add_entities(entities)


class IhaPanelButton(CoordinatorEntity[IhaCoordinator], ButtonEntity):
    """Base button attached to the thermostat device."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: IhaCoordinator, entry: ConfigEntry, suffix: str) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.serial = _panel_serial(coordinator, entry)
        self._attr_unique_id = f"{self.serial}_{suffix}"

    @property
    def available(self) -> bool:
        return self.coordinator.has_recent_status or super().available

    @property
    def device_info(self) -> DeviceInfo:
        climate = _current_panel_data(self.coordinator)
        data = self.coordinator.data or {}
        return DeviceInfo(
            identifiers={(DOMAIN, self.serial)},
            name=climate.get("name") or data.get("name") or DEFAULT_NAME,
            manufacturer=climate.get("manufacturer") or data.get("manufacturer") or "IHA",
            model=climate.get("model") or data.get("model") or "Wall Thermostat",
            sw_version=(
                climate.get("swVersion")
                or climate.get("sw_version")
                or data.get("swVersion")
                or data.get("sw_version")
            ),
        )


class IhaSyncNextChangeButton(IhaPanelButton):
    """Arm the same 30-second Sync window used by the wall screen."""

    _attr_name = "Sync Next Change"
    _attr_icon = "mdi:sync"

    def __init__(self, coordinator: IhaCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "sync_next_change")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self.coordinator.data or {}
        sync = data.get("sync") if isinstance(data.get("sync"), dict) else {}
        return {
            "iha_panel": True,
            "iha_serial": self.serial,
            "iha_action": "sync-next-change",
            "sync_armed": bool(sync.get("active", sync.get("armed", False))),
            "sync_remaining_seconds": sync.get("remainingSeconds", 0),
            "sync_configured_thermostats": sync.get("configuredCount", 0),
        }

    async def async_press(self) -> None:
        try:
            # Read the panel immediately and then send an explicit arm/off action.
            # A blind toggle can invert the wrong state when HA's coordinator copy
            # is a few seconds behind the wall screen.
            status = await self.coordinator.api.sync_status()
            active = bool(status.get("active", status.get("armed", False)))
            result = await self.coordinator.api.set_sync(not active, 30)
            self.coordinator.apply_sync_status(result)
        except Exception as exc:
            raise HomeAssistantError(f"Could not toggle thermostat sync: {exc}") from exc


class IhaArrivingSyncReceiverButton(IhaPanelButton):
    """Hidden receiver used for reliable Arriving peer synchronization."""

    _attr_name = "Arriving Sync Receiver"
    _attr_icon = "mdi:home-import-outline"
    _attr_entity_registry_visible_default = False
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, coordinator: IhaCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry, "arriving_sync_receiver")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {
            "iha_panel": True,
            "iha_serial": self.serial,
            "iha_action": "arriving-sync-receiver",
        }

    async def async_press(self) -> None:
        try:
            await self.coordinator.async_control(
                {
                    "preset_mode": "arriving",
                    "away": False,
                    "commandSource": "peer-sync",
                    "source": "peer-sync",
                    "presetChangeSource": "peer-sync",
                }
            )
        except Exception as exc:
            raise HomeAssistantError(f"Could not apply Arriving sync: {exc}") from exc


class IhaCheckForUpdatesButton(
    CoordinatorEntity[IhaUpdateCoordinator], ButtonEntity
):
    """Immediately check the thermostat's configured GitHub branch."""

    _attr_has_entity_name = True
    _attr_name = "Check for Updates"
    _attr_icon = "mdi:refresh"
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(
        self,
        coordinator: IhaUpdateCoordinator,
        panel_coordinator: IhaCoordinator,
        entry: ConfigEntry,
    ) -> None:
        super().__init__(coordinator)
        self.panel_coordinator = panel_coordinator
        self.entry = entry
        self.serial = _panel_serial(panel_coordinator, entry)
        self._attr_unique_id = f"{self.serial}_check_for_updates"

    @property
    def update_data(self) -> dict[str, Any]:
        """Return the latest software status payload."""
        return self.coordinator.data if isinstance(self.coordinator.data, dict) else {}

    @property
    def available(self) -> bool:
        """Allow checks whenever the panel is reachable and not installing."""
        return (
            not bool(self.update_data.get("inProgress"))
            and (
                bool(self.update_data)
                or self.panel_coordinator.has_recent_status
                or bool(self.panel_coordinator.data)
            )
        )

    @property
    def device_info(self) -> DeviceInfo:
        """Attach the button to the same thermostat device."""
        climate = _current_panel_data(self.panel_coordinator)
        data = self.panel_coordinator.data or {}
        return DeviceInfo(
            identifiers={(DOMAIN, self.serial)},
            name=climate.get("name") or data.get("name") or DEFAULT_NAME,
            manufacturer=climate.get("manufacturer")
            or data.get("manufacturer")
            or "IHA",
            model=climate.get("model") or data.get("model") or "Wall Thermostat",
            sw_version=(
                climate.get("swVersion")
                or climate.get("sw_version")
                or data.get("swVersion")
                or data.get("sw_version")
            ),
        )

    async def async_press(self) -> None:
        """Run an immediate GitHub availability check without installing."""
        try:
            await self.coordinator.async_check_for_updates()
        except Exception as exc:
            raise HomeAssistantError(f"Could not check for thermostat updates: {exc}") from exc
