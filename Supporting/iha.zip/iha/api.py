"""Local HTTP API client for the IHA panel."""

from __future__ import annotations

import asyncio
from typing import Any
from urllib.parse import urlparse

from aiohttp import ClientError, ClientResponseError, ClientSession, ClientTimeout


class IhaApiError(Exception):
    """Raised when the thermostat API cannot be reached or returns an error."""


def _normalize_host_port(host: str, port: int = 8080) -> tuple[str, int]:
    """Accept a bare IP/host or a full URL and return host + port.

    This keeps manual setup forgiving, so these all work:
    192.168.1.168, 192.168.1.168:8080, http://192.168.1.168:8080.
    """
    raw = str(host or "").strip()
    if not raw:
        return "", int(port or 8080)

    parsed = urlparse(raw if "://" in raw else f"//{raw}")
    parsed_host = parsed.hostname or raw.split("/", 1)[0]
    parsed_port = parsed.port or port or 8080
    parsed_host = parsed_host.strip().strip("[]").rstrip(".")
    return parsed_host, int(parsed_port)


class IhaApi:
    """Small async client for the Raspberry Pi thermostat API."""

    def __init__(self, session: ClientSession, host: str, port: int = 8080) -> None:
        self._session = session
        self.host, self.port = _normalize_host_port(host, port)

    @property
    def base_url(self) -> str:
        host = self.host
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        return f"http://{host}:{self.port}"

    async def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        method = str(method or "GET").upper()
        # The wall panel is on Wi-Fi and the Pi can occasionally take a little
        # longer to answer while the native UI, relay loop, or Home Assistant
        # proxy work is active. Retry idempotent reads once so a single dropped
        # packet does not make the HA climate entity flip to unavailable.
        attempts = 2 if method == "GET" else 1
        last_error: Exception | None = None
        for attempt in range(attempts):
            try:
                async with self._session.request(
                    method,
                    url,
                    json=payload,
                    timeout=ClientTimeout(total=15, connect=5, sock_connect=5, sock_read=12),
                ) as response:
                    response.raise_for_status()
                    data = await response.json(content_type=None)

                if isinstance(data, dict) and data.get("ok", True) is False:
                    raise IhaApiError(str(data.get("error") or "Thermostat API returned an error"))
                if not isinstance(data, dict):
                    raise IhaApiError("Thermostat API returned a non-object response")
                return data
            except IhaApiError as exc:
                last_error = exc
            except (ClientError, ClientResponseError, TimeoutError) as exc:
                last_error = IhaApiError(f"Could not reach thermostat at {url}: {exc}")
            except Exception as exc:  # JSON/content errors are still connection validation failures for HA.
                last_error = IhaApiError(f"Invalid thermostat response from {url}: {exc}")

            if attempt + 1 < attempts:
                await asyncio.sleep(0.35)

        assert last_error is not None
        if isinstance(last_error, IhaApiError):
            raise last_error
        raise IhaApiError(str(last_error)) from last_error

    async def discovery(self) -> dict[str, Any]:
        return await self._request("GET", "/api/discovery")

    async def status(self) -> dict[str, Any]:
        return await self._request("GET", "/api/thermostat/status")

    async def control(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self._request("POST", "/api/thermostat/control", payload)

    async def hardware_telemetry(self) -> dict[str, Any]:
        """Read onboard temperatures and motion without touching climate state."""
        return await self._request("GET", "/api/hardware/telemetry")

    async def motion_control(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Apply an explicit motion-sensor configuration change."""
        return await self._request("POST", "/api/hardware/motion", payload)

    async def update_status(self, refresh: bool = False) -> dict[str, Any]:
        """Read the panel software update state and optionally refresh GitHub."""
        path = "/api/system/update-status?refresh=1" if refresh else "/api/system/update-status"
        return await self._request("GET", path)

    async def fetch_update(self) -> dict[str, Any]:
        """Start the panel's existing safe transient-systemd updater."""
        return await self._request("POST", "/api/system/fetch-update", {})
