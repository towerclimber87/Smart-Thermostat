"""Local HTTP API client for an IHA wall thermostat."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from aiohttp import ClientError, ClientResponseError, ClientSession


class IhaApiError(Exception):
    """Raised when the IHA panel API cannot be used."""


class IhaApi:
    """Small async client for the thermostat's local JSON API."""

    def __init__(self, session: ClientSession, host: str, port: int = 8080) -> None:
        self.session = session
        self.host, self.port, self.base_url = self._normalize_address(host, port)

    @staticmethod
    def _normalize_address(host: str, port: int) -> tuple[str, int, str]:
        raw = str(host or "").strip().rstrip("/")
        requested_port = int(port or 8080)
        if "://" not in raw:
            clean_host = raw.strip("/")
            return clean_host, requested_port, f"http://{clean_host}:{requested_port}"

        parsed = urlparse(raw)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise IhaApiError("The IHA address must be a hostname, IP address, or HTTP URL.")
        effective_port = parsed.port or (443 if parsed.scheme == "https" else requested_port)
        netloc = parsed.hostname
        default_port = 443 if parsed.scheme == "https" else 80
        if effective_port != default_port:
            netloc = f"{netloc}:{effective_port}"
        base_path = parsed.path.rstrip("/")
        return parsed.hostname, effective_port, f"{parsed.scheme}://{netloc}{base_path}"

    async def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        *,
        timeout: float = 20,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        try:
            async with self.session.request(
                method,
                url,
                json=payload,
                timeout=timeout,
                headers={"Accept": "application/json"},
            ) as response:
                response.raise_for_status()
                data = await response.json(content_type=None)
        except ClientResponseError as exc:
            raise IhaApiError(f"IHA returned HTTP {exc.status} for {path}.") from exc
        except (ClientError, TimeoutError, ValueError, TypeError) as exc:
            raise IhaApiError(f"Could not reach IHA at {url}: {exc}") from exc
        if not isinstance(data, dict):
            raise IhaApiError(f"IHA returned an invalid response for {path}.")
        if data.get("ok") is False:
            raise IhaApiError(str(data.get("error") or data.get("message") or "IHA request failed."))
        return data

    async def discovery(self) -> dict[str, Any]:
        return await self._request("GET", "/api/discovery", timeout=10)

    async def status(self) -> dict[str, Any]:
        return await self._request("GET", "/api/thermostat/status", timeout=15)

    async def control(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self._request("POST", "/api/thermostat/control", payload, timeout=20)

    async def run_schedule(self, schedule_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/api/thermostat/run-schedule",
            {"scheduleId": schedule_id},
            timeout=20,
        )

    async def hardware_telemetry(self) -> dict[str, Any]:
        return await self._request("GET", "/api/hardware/telemetry", timeout=12)

    async def motion_status(self) -> dict[str, Any]:
        return await self._request("GET", "/api/hardware/motion", timeout=12)

    async def set_motion(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self._request("POST", "/api/hardware/motion", payload, timeout=15)

    async def update_status(self, *, refresh: bool = False) -> dict[str, Any]:
        suffix = "?refresh=1" if refresh else ""
        return await self._request("GET", f"/api/system/update-status{suffix}", timeout=20)

    async def install_update(self) -> dict[str, Any]:
        return await self._request("POST", "/api/system/fetch-update", {}, timeout=90)

    async def assistant_process(self, payload: dict[str, Any]) -> dict[str, Any]:
        return await self._request("POST", "/api/assistant/process", payload, timeout=120)

    async def assistant_playback(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Update the wall panel while Home Assistant owns TTS playback."""
        return await self._request("POST", "/api/assistant/playback", payload, timeout=15)
