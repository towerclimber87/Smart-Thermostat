"""Config flow for IHA."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.components import zeroconf
from homeassistant.const import CONF_HOST, CONF_PORT
from homeassistant.core import callback
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import IhaApi, IhaApiError
from .const import CONF_SERIAL, DEFAULT_NAME, DEFAULT_PORT, DOMAIN


def _split_host(value: str, port: int) -> tuple[str, int]:
    raw = str(value or "").strip().rstrip("/")
    if "://" not in raw:
        return raw, int(port or DEFAULT_PORT)
    parsed = urlparse(raw)
    if not parsed.hostname:
        return raw, int(port or DEFAULT_PORT)
    return raw, int(parsed.port or port or DEFAULT_PORT)


class IhaConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle IHA setup and discovery."""

    VERSION = 1

    def __init__(self) -> None:
        self._discovered: dict[str, Any] = {}

    async def _probe(self, host: str, port: int) -> dict[str, Any]:
        api = IhaApi(async_get_clientsession(self.hass), host, port)
        return await api.discovery()

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        errors: dict[str, str] = {}
        if user_input is not None:
            host, port = _split_host(user_input[CONF_HOST], user_input.get(CONF_PORT, DEFAULT_PORT))
            try:
                info = await self._probe(host, port)
            except IhaApiError:
                errors["base"] = "cannot_connect"
            else:
                serial = str(info.get("serial") or info.get("unique_id") or f"{host}:{port}")
                await self.async_set_unique_id(serial)
                self._abort_if_unique_id_configured(updates={CONF_HOST: host, CONF_PORT: port})
                name = str(info.get("name") or info.get("thermostatName") or DEFAULT_NAME)
                return self.async_create_entry(
                    title=name,
                    data={CONF_HOST: host, CONF_PORT: port, CONF_SERIAL: serial},
                )
        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_HOST): str,
                    vol.Optional(CONF_PORT, default=DEFAULT_PORT): int,
                }
            ),
            errors=errors,
        )

    async def async_step_zeroconf(self, discovery_info: zeroconf.ZeroconfServiceInfo):
        host = discovery_info.host
        port = int(discovery_info.port or DEFAULT_PORT)
        try:
            info = await self._probe(host, port)
        except IhaApiError:
            return self.async_abort(reason="cannot_connect")
        serial = str(info.get("serial") or info.get("unique_id") or discovery_info.name)
        await self.async_set_unique_id(serial)
        self._abort_if_unique_id_configured(updates={CONF_HOST: host, CONF_PORT: port, CONF_SERIAL: serial})
        self._discovered = {
            CONF_HOST: host,
            CONF_PORT: port,
            CONF_SERIAL: serial,
            "name": str(info.get("name") or info.get("thermostatName") or DEFAULT_NAME),
        }
        self.context["title_placeholders"] = {"name": self._discovered["name"]}
        return await self.async_step_confirm()

    async def async_step_confirm(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            return self.async_create_entry(
                title=self._discovered.get("name", DEFAULT_NAME),
                data={
                    CONF_HOST: self._discovered[CONF_HOST],
                    CONF_PORT: self._discovered[CONF_PORT],
                    CONF_SERIAL: self._discovered[CONF_SERIAL],
                },
            )
        return self.async_show_form(
            step_id="confirm",
            description_placeholders={"name": self._discovered.get("name", DEFAULT_NAME)},
        )
