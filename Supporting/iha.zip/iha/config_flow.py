"""Config flow for IHA."""

from __future__ import annotations

import ipaddress
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_NAME, CONF_PORT
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.service_info.zeroconf import ZeroconfServiceInfo

from .api import IhaApi, IhaApiError, _normalize_host_port
from .const import CONF_API_PATH, CONF_SERIAL, DEFAULT_NAME, DEFAULT_PORT, DOMAIN


def _clean_property(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="ignore")
    return str(value or "")


def _clean_host(value: Any) -> str:
    """Convert zeroconf host/address values to a connectable host string."""
    if value is None:
        return ""
    if isinstance(value, (bytes, bytearray)):
        try:
            return str(ipaddress.ip_address(bytes(value)))
        except ValueError:
            return value.decode("utf-8", errors="ignore").strip().strip("[]").rstrip(".")
    if isinstance(value, (list, tuple, set)):
        for item in value:
            host = _clean_host(item)
            if host:
                return host
        return ""
    return str(value).strip().strip("[]").rstrip(".")


def _discovery_host(discovery_info: ZeroconfServiceInfo) -> str:
    """Prefer an IP address from HA zeroconf, then fall back to hostname."""
    for attr in ("ip_address", "host", "hostname", "addresses", "ip_addresses"):
        host = _clean_host(getattr(discovery_info, attr, None))
        if host:
            return host
    return ""


def _discovery_serial(discovery: dict[str, Any], fallback: str = "") -> str:
    """Read the stable panel serial from new and older discovery payloads."""
    climate = discovery.get("climate") or discovery.get("thermostat")
    if not isinstance(climate, dict):
        climate = {}
    return str(
        discovery.get("serial")
        or discovery.get("unique_id")
        or discovery.get("id")
        or discovery.get("hardware_id")
        or discovery.get("mac_address")
        or climate.get("serial")
        or climate.get("unique_id")
        or climate.get("id")
        or climate.get("hardware_id")
        or climate.get("mac_address")
        or fallback
    ).strip()


async def _async_validate(hass: HomeAssistant, host: str, port: int) -> tuple[dict[str, Any], str, int]:
    session = async_get_clientsession(hass)
    api = IhaApi(session, host, port)
    discovery = await api.discovery()
    return discovery, api.host, api.port


class IhaConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle an IHA config flow."""

    VERSION = 1

    def __init__(self) -> None:
        self._discovery_data: dict[str, Any] = {}
        self._discovery_title = DEFAULT_NAME

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        errors: dict[str, str] = {}
        if user_input is not None:
            host, port = _normalize_host_port(user_input[CONF_HOST], int(user_input.get(CONF_PORT, DEFAULT_PORT)))
            try:
                discovery, host, port = await _async_validate(self.hass, host, port)
            except IhaApiError:
                errors["base"] = "cannot_connect"
            else:
                serial = _discovery_serial(discovery, f"{host}:{port}")
                await self.async_set_unique_id(serial)
                self._abort_if_unique_id_configured(updates={CONF_HOST: host, CONF_PORT: port})
                title = str(discovery.get("name") or DEFAULT_NAME)
                return self.async_create_entry(
                    title=title,
                    data={
                        CONF_HOST: host,
                        CONF_PORT: port,
                        CONF_NAME: title,
                        CONF_SERIAL: serial,
                        CONF_API_PATH: str(discovery.get("api_path") or "/api"),
                    },
                )

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_HOST): str,
                    vol.Optional(CONF_PORT, default=DEFAULT_PORT): int,
                }
            ),
            errors=errors,
        )

    async def async_step_zeroconf(self, discovery_info: ZeroconfServiceInfo):
        props = discovery_info.properties or {}
        host = _discovery_host(discovery_info)
        port = int(discovery_info.port or DEFAULT_PORT)
        name = _clean_property(props.get("name")) or DEFAULT_NAME

        if not host:
            return self.async_abort(reason="cannot_connect")

        try:
            discovery, host, port = await _async_validate(self.hass, host, port)
        except IhaApiError:
            return self.async_abort(reason="cannot_connect")

        serial = _discovery_serial(
            discovery,
            _clean_property(props.get("serial"))
            or _clean_property(props.get("unique_id"))
            or _clean_property(props.get("id"))
            or _clean_property(props.get("mac_address"))
            or f"{host}:{port}",
        )
        await self.async_set_unique_id(serial)
        self._abort_if_unique_id_configured(updates={CONF_HOST: host, CONF_PORT: port})
        self._discovery_title = str(discovery.get("name") or name)
        self._discovery_data = {
            CONF_HOST: host,
            CONF_PORT: port,
            CONF_NAME: self._discovery_title,
            CONF_SERIAL: serial,
            CONF_API_PATH: str(discovery.get("api_path") or _clean_property(props.get("path")) or "/api"),
        }
        self.context["title_placeholders"] = {"name": self._discovery_title}
        return await self.async_step_confirm()

    async def async_step_confirm(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            return self.async_create_entry(title=self._discovery_title, data=self._discovery_data)
        return self.async_show_form(step_id="confirm", description_placeholders={"name": self._discovery_title})
