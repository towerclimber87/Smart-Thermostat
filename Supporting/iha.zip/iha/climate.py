"""Climate platform for an IHA wall thermostat."""

from __future__ import annotations

from typing import Any

from homeassistant.components.climate import ClimateEntity
from homeassistant.components.climate.const import ClimateEntityFeature, HVACAction, HVACMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import ATTR_TEMPERATURE, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaCoordinatorEntity, climate_data


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([IhaClimate(entry, coordinator)])


class IhaClimate(IhaCoordinatorEntity, ClimateEntity):
    """The primary thermostat entity."""

    _attr_name = None
    _attr_icon = "mdi:thermostat"
    _attr_temperature_unit = UnitOfTemperature.FAHRENHEIT
    _attr_target_temperature_step = 1.0
    _attr_supported_features = (
        ClimateEntityFeature.TARGET_TEMPERATURE
        | ClimateEntityFeature.FAN_MODE
        | ClimateEntityFeature.PRESET_MODE
        | ClimateEntityFeature.TURN_ON
        | ClimateEntityFeature.TURN_OFF
    )

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(entry, coordinator)
        # The original integration used the physical panel serial for the main
        # climate entity. Retaining it lets the existing entity registry revive
        # the same climate.* entity IDs and keeps automations intact.
        self._attr_unique_id = self._serial

    @property
    def _data(self) -> dict[str, Any]:
        return climate_data(self.coordinator.data)

    @property
    def current_temperature(self) -> float | None:
        return self._number("current_temperature", "currentTemp")

    @property
    def current_humidity(self) -> float | None:
        return self._number("humidity")

    @property
    def target_temperature(self) -> float | None:
        return self._number("target_temperature", "temperature", "targetTemp")

    @property
    def hvac_mode(self) -> HVACMode:
        raw = str(self._first("hvac_mode", "hvacMode", "mode") or "off").lower()
        aliases = {"auto": HVACMode.HEAT_COOL, "heat_cool": HVACMode.HEAT_COOL}
        if raw in aliases:
            return aliases[raw]
        try:
            return HVACMode(raw)
        except ValueError:
            return HVACMode.OFF

    @property
    def hvac_modes(self) -> list[HVACMode]:
        raw_modes = self._first("hvac_modes", "hvacModes")
        if not isinstance(raw_modes, list):
            raw_modes = ["off", "heat", "cool"]
        result: list[HVACMode] = []
        for raw in raw_modes:
            value = "heat_cool" if str(raw).lower() == "auto" else str(raw).lower()
            try:
                mode = HVACMode(value)
            except ValueError:
                continue
            if mode not in result:
                result.append(mode)
        if HVACMode.OFF not in result:
            result.insert(0, HVACMode.OFF)
        return result

    @property
    def hvac_action(self) -> HVACAction:
        raw = str(self._first("hvac_action", "hvacAction") or "idle").lower()
        aliases = {"fan": HVACAction.FAN, "fan_only": HVACAction.FAN}
        if raw in aliases:
            return aliases[raw]
        try:
            return HVACAction(raw)
        except ValueError:
            return HVACAction.IDLE

    @property
    def fan_mode(self) -> str | None:
        value = self._first("fan_mode", "fanMode", "fan")
        return str(value) if value is not None else None

    @property
    def fan_modes(self) -> list[str]:
        return ["auto", "on", "off"]

    @property
    def preset_mode(self) -> str | None:
        arriving = bool(self._first("arriving_active", "arrivingActive"))
        if arriving:
            return "arriving"
        value = self._first("preset_mode", "presetMode")
        if value:
            return str(value)
        return "away" if bool(self._first("away")) else "home"

    @property
    def preset_modes(self) -> list[str]:
        return ["home", "away", "arriving"]

    @property
    def min_temp(self) -> float:
        limits = self._data.get("limits") if isinstance(self._data.get("limits"), dict) else {}
        key = "auto" if self.hvac_mode is HVACMode.HEAT_COOL else self.hvac_mode.value
        values = limits.get(key) if isinstance(limits.get(key), dict) else {}
        return float(values.get("min", 55))

    @property
    def max_temp(self) -> float:
        limits = self._data.get("limits") if isinstance(self._data.get("limits"), dict) else {}
        key = "auto" if self.hvac_mode is HVACMode.HEAT_COOL else self.hvac_mode.value
        values = limits.get(key) if isinstance(limits.get(key), dict) else {}
        return float(values.get("max", 90))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self._data
        pause = data.get("pauseFunction") if isinstance(data.get("pauseFunction"), dict) else {}
        sync = data.get("sync") if isinstance(data.get("sync"), dict) else {}
        outputs = data.get("outputs") if isinstance(data.get("outputs"), dict) else {}
        relays = data.get("relays") if isinstance(data.get("relays"), dict) else {}
        return {
            "outdoor_temperature": self._first("outdoor_temperature", "outdoorTemp"),
            "heat_relay": bool(relays.get("heat")),
            "cool_relay": bool(relays.get("cool")),
            "fan_relay": bool(relays.get("fan")),
            "control_mode": outputs.get("controlMode") or data.get("mode"),
            "heat_lockout": bool(data.get("heatLocked")),
            "cool_lockout": bool(data.get("coolLocked")),
            "safety_mode": data.get("safetyMode") or "",
            "target_temperature_locked_by_preset": bool(data.get("away")),
            "arriving_active": bool(data.get("arriving_active") or data.get("arrivingActive")),
            "arriving_expires_at": data.get("arriving_expires_at") or data.get("arrivingExpiresAt") or 0,
            "arriving_remaining_seconds": data.get("arriving_remaining_seconds") or data.get("arrivingRemainingSeconds") or 0,
            "iha_panel": True,
            "iha_sync_capable": True,
            "iha_serial": self._serial,
            "iha_panel_url": self.coordinator.api.base_url,
            "iha_thermostat_name": data.get("name") or self.entry.title,
            "iha_sync_armed": bool(sync.get("armed") or data.get("syncArmed")),
            "iha_sync_remaining_seconds": sync.get("remainingSeconds") or data.get("syncRemainingSeconds") or 0,
            "iha_sync_configured_thermostats": sync.get("configuredCount") or 0,
            "manufacturer": "IHA",
            "model": "Wall Thermostat",
            "door_pause_active": bool(pause.get("active")),
            "door_pause_snooze_until": pause.get("snoozeUntil") or 0,
            "door_pause_active_entity_ids": pause.get("activeEntityIds") or [],
            "iha_api_status_source": "live" if self.coordinator.last_update_success else "cached",
            "iha_entity_available_from_cache": self.coordinator.data is not None,
            "iha_api_consecutive_failures": 0 if self.coordinator.last_update_success else 1,
            "iha_api_last_success_at": None,
            "iha_api_last_success_age_seconds": 0,
            "iha_api_last_error": None if self.coordinator.last_update_success else "Panel status unavailable",
            "iha_api_poll_seconds": int(self.coordinator.update_interval.total_seconds()) if self.coordinator.update_interval else 10,
            "iha_api_stale_status_seconds": 600,
        }

    async def async_set_temperature(self, **kwargs: Any) -> None:
        temperature = kwargs.get(ATTR_TEMPERATURE)
        if temperature is None:
            return
        await self._send({"targetTemp": float(temperature), "targetChangeSource": "home-assistant-command"})

    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        mode = "auto" if hvac_mode is HVACMode.HEAT_COOL else hvac_mode.value
        await self._send({"mode": mode, "modeChangeSource": "home-assistant-command"})

    async def async_set_fan_mode(self, fan_mode: str) -> None:
        await self._send({"fan": fan_mode, "source": "home-assistant-command"})

    async def async_set_preset_mode(self, preset_mode: str) -> None:
        await self._send({"preset_mode": preset_mode, "source": "home-assistant-command"})

    async def async_turn_on(self) -> None:
        preferred = str(self._data.get("mode") or "cool")
        if preferred == "off":
            preferred = "cool"
        await self.async_set_hvac_mode(HVACMode.HEAT_COOL if preferred == "auto" else HVACMode(preferred))

    async def async_turn_off(self) -> None:
        await self.async_set_hvac_mode(HVACMode.OFF)

    async def _send(self, payload: dict[str, Any]) -> None:
        result = await self.coordinator.api.control(payload)
        self.coordinator.async_set_updated_data(result)

    def _first(self, *keys: str) -> Any:
        for key in keys:
            if key in self._data:
                return self._data.get(key)
        return None

    def _number(self, *keys: str) -> float | None:
        value = self._first(*keys)
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None
