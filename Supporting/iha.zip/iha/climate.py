"""Climate platform for IHA."""

from __future__ import annotations

from typing import Any
import logging
import time

from homeassistant.components.climate import ClimateEntity
from homeassistant.components.climate.const import (
    ClimateEntityFeature,
    HVACAction,
    HVACMode,
)
from homeassistant.const import ATTR_TEMPERATURE, PRECISION_WHOLE, UnitOfTemperature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import CONF_SERIAL, DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator

_LOGGER = logging.getLogger(__name__)

FAN_MODES = ["auto", "on", "off"]
PRESET_HOME = "home"
PRESET_AWAY = "away"
PRESET_ARRIVING = "arriving"
ARRIVING_BYPASS_MS = 2 * 60 * 60 * 1000
MODE_TO_HA = {
    "off": HVACMode.OFF,
    "heat": HVACMode.HEAT,
    "cool": HVACMode.COOL,
    "auto": HVACMode.HEAT_COOL,
    "heat_cool": HVACMode.HEAT_COOL,
}
HA_TO_MODE = {value: key for key, value in MODE_TO_HA.items()}
HA_TO_MODE[HVACMode.HEAT_COOL] = "auto"

# Home Assistant voice/cloud commands can call climate.set_temperature with
# these service keys instead of a plain `temperature`. Keep the strings local
# instead of importing optional constants so the custom integration stays
# compatible across HA versions.
ATTR_HVAC_MODE = "hvac_mode"
ATTR_TARGET_TEMP_HIGH = "target_temp_high"
ATTR_TARGET_TEMP_LOW = "target_temp_low"


def _normalize_requested_hvac_mode(hvac_mode: HVACMode | str) -> str:
    """Convert Home Assistant HVAC mode values to the panel mode string.

    Some HA versions pass HVACMode enum values and others pass plain strings.
    A direct dict lookup can miss plain strings and fall back to off, which makes
    selecting Cool in HA send off to the wall panel.
    """
    if hvac_mode in HA_TO_MODE:
        return HA_TO_MODE[hvac_mode]  # type: ignore[index]
    value = str(hvac_mode or "").strip().lower()
    if value.startswith("hvacmode."):
        value = value.split(".", 1)[1]
    if value in {"heat_cool", "auto"}:
        return "auto"
    if value in {"cool", "heat", "off"}:
        return value
    return "off"


def _normalize_reported_hvac_mode(value: object) -> HVACMode:
    """Convert the panel's reported mode back into a Home Assistant mode."""
    mode = str(value or "off").strip().lower()
    if mode.startswith("hvacmode."):
        mode = mode.split(".", 1)[1]
    return MODE_TO_HA.get(mode, HVACMode.OFF)


def _requested_temperature_from_kwargs(kwargs: dict[str, Any], current_mode: object | None = None) -> Any | None:
    """Extract a single-panel target temperature from HA service kwargs.

    The HA climate card normally sends `temperature`, but voice assistants can
    send `hvac_mode` plus high/low range keys. The wall panel has one active
    comfort target, so map those range-style requests back to one setpoint.
    """
    for key in (ATTR_TEMPERATURE, "target_temperature", "targetTemp", "targetTemperature"):
        if key in kwargs:
            return kwargs[key]

    high = kwargs.get(ATTR_TARGET_TEMP_HIGH, kwargs.get("targetTemperatureHigh"))
    low = kwargs.get(ATTR_TARGET_TEMP_LOW, kwargs.get("targetTemperatureLow"))
    requested_mode = _normalize_requested_hvac_mode(kwargs.get(ATTR_HVAC_MODE, current_mode or ""))

    if requested_mode == "cool" and high is not None:
        return high
    if requested_mode == "heat" and low is not None:
        return low
    if high is not None and low is not None:
        try:
            return round((float(high) + float(low)) / 2)
        except (TypeError, ValueError):
            return high
    if high is not None:
        return high
    if low is not None:
        return low
    return None


ACTION_TO_HA = {
    "off": HVACAction.OFF,
    "idle": HVACAction.IDLE,
    "heating": HVACAction.HEATING,
    "cooling": HVACAction.COOLING,
    "fan": getattr(HVACAction, "FAN", HVACAction.IDLE),
}


def _boolish(value: object) -> bool:
    """Return True for the common truthy forms the panel API may send."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value or "").strip().lower()
    return text in {"1", "true", "yes", "on", "enabled", "away"}


def _arriving_override_active(data: dict[str, Any] | None) -> bool:
    """Return True while the panel's two-hour Arriving bypass is active."""
    if not isinstance(data, dict):
        return False
    explicit = str(data.get("preset_mode") or data.get("presetMode") or "").strip().lower()
    if explicit == PRESET_ARRIVING:
        return True
    override = data.get("presenceHomeOverride") or data.get("presence_home_override")
    if not isinstance(override, dict) or not _boolish(override.get("active", True)):
        return False
    if str(override.get("reason") or "").strip().lower() != PRESET_ARRIVING:
        return False
    expires_at = override.get("expiresAt", override.get("expires_at", override.get("until", 0)))
    try:
        expires_ms = float(expires_at or 0)
    except (TypeError, ValueError):
        expires_ms = 0
    return expires_ms <= 0 or int(time.time() * 1000) < expires_ms


def _arriving_override_payload(data: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build the panel payload that holds Auto Away off for two hours."""
    entity_ids: list[str] = []
    if isinstance(data, dict):
        people = data.get("autoAwayPeople") or data.get("people") or []
        if isinstance(people, list):
            for person in people:
                if isinstance(person, dict):
                    entity_id = str(person.get("entity_id") or person.get("entityId") or "").strip()
                    if entity_id and entity_id not in entity_ids:
                        entity_ids.append(entity_id)
    now_ms = int(time.time() * 1000)
    return {
        "active": True,
        "startedAt": now_ms,
        "entityIds": entity_ids,
        "reason": PRESET_ARRIVING,
        "durationMs": ARRIVING_BYPASS_MS,
        "expiresAt": now_ms + ARRIVING_BYPASS_MS,
    }


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up the thermostat climate entity."""
    coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([IhaClimate(coordinator, entry)])


class IhaClimate(CoordinatorEntity[IhaCoordinator], ClimateEntity):
    """IHA climate entity."""

    _attr_has_entity_name = True
    _attr_name = None
    _attr_supported_features = (
        ClimateEntityFeature.TARGET_TEMPERATURE
        | ClimateEntityFeature.FAN_MODE
        | ClimateEntityFeature.PRESET_MODE
    )
    _attr_temperature_unit = UnitOfTemperature.FAHRENHEIT
    _attr_target_temperature_step = 1.0
    _attr_precision = PRECISION_WHOLE

    def __init__(self, coordinator: IhaCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator)
        self._entry = entry
        data = coordinator.data or {}
        self._serial = str(
            data.get("serial")
            or data.get("unique_id")
            or data.get("id")
            or data.get("hardware_id")
            or data.get("mac_address")
            or self.climate_data.get("serial")
            or self.climate_data.get("unique_id")
            or self.climate_data.get("id")
            or self.climate_data.get("hardware_id")
            or self.climate_data.get("mac_address")
            or entry.data.get(CONF_SERIAL)
            or entry.unique_id
            or entry.entry_id
        ).strip()
        self._attr_unique_id = f"{self._serial}_climate"

    @property
    def available(self) -> bool:
        """Keep the entity available during short Wi-Fi/API hiccups.

        Home Assistant's default CoordinatorEntity marks the entity unavailable
        as soon as one coordinator refresh raises UpdateFailed. The panel is a
        local Wi-Fi device, so one missed poll should not make automations and
        history flap. The coordinator exposes the last successful response age;
        use that cached data until it is truly stale.
        """
        return self.coordinator.has_recent_status or super().available

    @property
    def climate_data(self) -> dict[str, Any]:
        data = self.coordinator.data or {}
        climate = data.get("climate") or data.get("thermostat")
        return climate if isinstance(climate, dict) else data

    @property
    def outputs(self) -> dict[str, Any]:
        data = self.coordinator.data or {}
        outputs = data.get("outputs")
        if isinstance(outputs, dict):
            return outputs
        relays = data.get("relays")
        if isinstance(relays, dict):
            return {
                "fan": relays.get("fan"),
                "heat": relays.get("heat"),
                "cool": relays.get("cool"),
                "controlMode": data.get("controlMode") or data.get("mode"),
            }
        return {
            "fan": data.get("relayFan"),
            "heat": data.get("relayHeat"),
            "cool": data.get("relayCool"),
            "controlMode": data.get("controlMode") or data.get("mode"),
        }

    @property
    def away_active(self) -> bool:
        """Return whether the panel says Away mode is active."""
        data = self.climate_data
        preset = str(data.get("preset_mode") or data.get("presetMode") or "").strip().lower()
        return _boolish(data.get("away")) or preset == PRESET_AWAY

    @property
    def device_info(self) -> DeviceInfo:
        data = self.climate_data
        return DeviceInfo(
            identifiers={(DOMAIN, str(self._serial))},
            name=data.get("name") or DEFAULT_NAME,
            manufacturer=data.get("manufacturer") or "IHA",
            model=data.get("model") or "Wall Thermostat",
            sw_version=data.get("swVersion") or data.get("sw_version"),
        )

    @property
    def current_temperature(self) -> float | None:
        return self.climate_data.get("current_temperature", self.climate_data.get("currentTemp"))

    @property
    def target_temperature(self) -> float | None:
        return self.climate_data.get("target_temperature", self.climate_data.get("targetTemp"))

    @property
    def current_humidity(self) -> int | None:
        return self.climate_data.get("current_humidity", self.climate_data.get("humidity"))

    @property
    def min_temp(self) -> float:
        data = self.climate_data
        if "min_temp" in data:
            return float(data.get("min_temp", 45))
        limits = data.get("limits") if isinstance(data.get("limits"), dict) else {}
        active = "auto" if data.get("mode") == "auto" else str(data.get("mode") or "cool")
        active_limits = limits.get(active) if isinstance(limits.get(active), dict) else {}
        return float(active_limits.get("min", 45))

    @property
    def max_temp(self) -> float:
        data = self.climate_data
        if "max_temp" in data:
            return float(data.get("max_temp", 95))
        limits = data.get("limits") if isinstance(data.get("limits"), dict) else {}
        active = "auto" if data.get("mode") == "auto" else str(data.get("mode") or "cool")
        active_limits = limits.get(active) if isinstance(limits.get(active), dict) else {}
        return float(active_limits.get("max", 95))

    @property
    def hvac_modes(self) -> list[HVACMode]:
        return [HVACMode.OFF, HVACMode.HEAT, HVACMode.COOL, HVACMode.HEAT_COOL]

    @property
    def hvac_mode(self) -> HVACMode | None:
        data = self.climate_data
        return _normalize_reported_hvac_mode(data.get("raw_mode") or data.get("hvac_mode") or data.get("mode"))

    @property
    def hvac_action(self) -> HVACAction | None:
        return ACTION_TO_HA.get(str(self.climate_data.get("hvac_action") or "idle"), HVACAction.IDLE)

    @property
    def fan_modes(self) -> list[str]:
        return FAN_MODES

    @property
    def fan_mode(self) -> str | None:
        mode = str(self.climate_data.get("fan_mode") or self.climate_data.get("fan") or "auto")
        return mode if mode in FAN_MODES else "auto"

    @property
    def preset_modes(self) -> list[str]:
        return [PRESET_HOME, PRESET_AWAY, PRESET_ARRIVING]

    @property
    def arriving_active(self) -> bool:
        """Return whether Arriving mode is currently bypassing Auto Away."""
        return _arriving_override_active(self.climate_data)

    @property
    def preset_mode(self) -> str | None:
        if self.away_active:
            return PRESET_AWAY
        return PRESET_ARRIVING if self.arriving_active else PRESET_HOME

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self.climate_data
        panel_data = self.coordinator.data or {}
        sync = panel_data.get("sync") if isinstance(panel_data.get("sync"), dict) else data.get("sync")
        sync = sync if isinstance(sync, dict) else {}
        diagnostics = self.coordinator.connection_diagnostics
        pause = data.get("pauseFunction") if isinstance(data.get("pauseFunction"), dict) else {}
        override = data.get("presenceHomeOverride") if isinstance(data.get("presenceHomeOverride"), dict) else {}
        expires_at = override.get("expiresAt") if isinstance(override, dict) else None
        arriving_remaining = None
        if self.arriving_active and expires_at:
            try:
                arriving_remaining = max(0, int((float(expires_at) - int(time.time() * 1000)) / 1000))
            except (TypeError, ValueError):
                arriving_remaining = None
        return {
            "outdoor_temperature": data.get("outdoor_temperature"),
            "heat_relay": self.outputs.get("heat"),
            "cool_relay": self.outputs.get("cool"),
            "fan_relay": self.outputs.get("fan"),
            "control_mode": self.outputs.get("controlMode"),
            "heat_lockout": bool(data.get("heatLocked")),
            "cool_lockout": bool(data.get("coolLocked")),
            "safety_mode": data.get("safetyMode"),
            "target_temperature_locked_by_preset": self.away_active,
            "arriving_active": self.arriving_active,
            "arriving_expires_at": expires_at,
            "arriving_remaining_seconds": arriving_remaining,
            "iha_panel": True,
            "iha_sync_capable": True,
            "iha_serial": self._serial,
            # Home Assistant remains the discovery directory, but peer panels can
            # deliver synchronized commands directly to this current local API
            # address. This survives climate entity renames and avoids silent HA
            # service no-ops for Arriving/setpoint synchronization.
            "iha_panel_url": self.coordinator.api.base_url,
            "iha_thermostat_name": data.get("name") or self.device_name,
            "iha_sync_armed": bool(sync.get("active", sync.get("armed", False))),
            "iha_sync_remaining_seconds": sync.get("remainingSeconds", 0),
            "iha_sync_configured_thermostats": sync.get("configuredCount", 0),
            "manufacturer": "IHA",
            "model": "Wall Thermostat",
            "door_pause_active": bool(pause.get("active")),
            "door_pause_snooze_until": pause.get("snoozeUntil"),
            "door_pause_active_entity_ids": pause.get("activeEntityIds") if isinstance(pause.get("activeEntityIds"), list) else [],
            "iha_api_status_source": "cached" if diagnostics.get("using_cached_status") else "live",
            "iha_entity_available_from_cache": diagnostics.get("entity_available_from_cache"),
            "iha_api_consecutive_failures": diagnostics.get("consecutive_failures"),
            "iha_api_last_success_at": diagnostics.get("last_success_at"),
            "iha_api_last_success_age_seconds": diagnostics.get("last_success_age_seconds"),
            "iha_api_last_error": diagnostics.get("last_error"),
            "iha_api_poll_seconds": diagnostics.get("poll_seconds"),
            "iha_api_stale_status_seconds": diagnostics.get("stale_status_seconds"),
        }

    async def async_set_temperature(self, **kwargs: Any) -> None:
        payload: dict[str, Any] = {}

        requested_hvac_mode = kwargs.get(ATTR_HVAC_MODE)
        if requested_hvac_mode is not None:
            payload["hvac_mode"] = _normalize_requested_hvac_mode(requested_hvac_mode)

        requested_temperature = _requested_temperature_from_kwargs(kwargs, self.hvac_mode)
        if requested_temperature is not None:
            if self.away_active:
                # The wall panel owns the Away setpoint. Do not let a HA card,
                # automation, or cloud command overwrite the active Away target.
                # Still allow an accompanying HVAC-mode command through.
                _LOGGER.info(
                    "Ignoring Home Assistant target temperature %s because IHA Away mode is active",
                    requested_temperature,
                )
            else:
                payload["target_temperature"] = requested_temperature

        if not payload:
            await self.coordinator.async_request_refresh()
            return

        await self.coordinator.async_control(payload)

    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        await self.coordinator.async_control({"hvac_mode": _normalize_requested_hvac_mode(hvac_mode)})

    async def async_set_fan_mode(self, fan_mode: str) -> None:
        await self.coordinator.async_control({"fan_mode": fan_mode})

    async def async_set_preset_mode(self, preset_mode: str) -> None:
        requested = str(preset_mode or "").strip().lower()
        if requested == PRESET_ARRIVING:
            await self.coordinator.async_control({
                "preset_mode": PRESET_ARRIVING,
                "away": False,
                "presenceHomeOverride": _arriving_override_payload(self.climate_data),
            })
            return
        if requested == PRESET_AWAY:
            await self.coordinator.async_control({
                "preset_mode": PRESET_AWAY,
                "away": True,
                "presenceHomeOverride": None,
            })
            return
        if requested == PRESET_HOME:
            await self.coordinator.async_control({
                "preset_mode": PRESET_HOME,
                "away": False,
                "presenceHomeOverride": None,
            })
            return
        await self.coordinator.async_control({"preset_mode": requested or preset_mode})

    async def async_turn_off(self) -> None:
        await self.async_set_hvac_mode(HVACMode.OFF)

    async def async_turn_on(self) -> None:
        current = self.hvac_mode
        if current == HVACMode.OFF:
            await self.async_set_hvac_mode(HVACMode.COOL)
