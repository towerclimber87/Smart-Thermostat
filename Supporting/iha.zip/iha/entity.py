"""Shared entity helpers for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import CONF_SERIAL, DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator


def climate_data(data: object) -> dict[str, Any]:
    """Return the normalized climate object from a status response."""
    if not isinstance(data, dict):
        return {}
    nested = data.get("climate") or data.get("thermostat")
    return nested if isinstance(nested, dict) else data


def panel_serial(entry: ConfigEntry, coordinator: IhaCoordinator) -> str:
    data = coordinator.data if isinstance(coordinator.data, dict) else {}
    climate = climate_data(data)
    return str(
        data.get("serial")
        or data.get("unique_id")
        or climate.get("serial")
        or climate.get("unique_id")
        or entry.data.get(CONF_SERIAL)
        or entry.unique_id
        or f"{coordinator.api.host}:{coordinator.api.port}"
    ).strip()


class IhaCoordinatorEntity(CoordinatorEntity[IhaCoordinator]):
    """Base entity attached to one IHA panel."""

    _attr_has_entity_name = True

    def __init__(self, entry: ConfigEntry, coordinator: IhaCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self._serial = panel_serial(entry, coordinator)

    @property
    def device_info(self) -> DeviceInfo:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        climate = climate_data(data)
        name = str(climate.get("name") or data.get("name") or self.entry.title or DEFAULT_NAME)
        model = str(data.get("model") or climate.get("model") or "Wall Thermostat")
        software = str(
            data.get("swVersion")
            or data.get("sw_version")
            or climate.get("swVersion")
            or climate.get("sw_version")
            or ""
        )
        return DeviceInfo(
            identifiers={(DOMAIN, self._serial)},
            name=name,
            manufacturer=str(data.get("manufacturer") or climate.get("manufacturer") or "IHA"),
            model=model,
            sw_version=software or None,
            configuration_url=self.coordinator.api.base_url,
        )
