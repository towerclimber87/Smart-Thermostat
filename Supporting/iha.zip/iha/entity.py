"""Shared entities for IHA onboard hardware."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import CONF_SERIAL, DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator


def _current_panel_data(coordinator: IhaCoordinator) -> dict[str, Any]:
    data = coordinator.data or {}
    climate = data.get("climate") or data.get("thermostat")
    return climate if isinstance(climate, dict) else data


def _panel_serial(coordinator: IhaCoordinator, entry: ConfigEntry) -> str:
    data = coordinator.data or {}
    climate = _current_panel_data(coordinator)
    return str(
        data.get("serial")
        or data.get("unique_id")
        or data.get("id")
        or data.get("hardware_id")
        or data.get("mac_address")
        or climate.get("serial")
        or climate.get("unique_id")
        or climate.get("id")
        or climate.get("hardware_id")
        or climate.get("mac_address")
        or entry.data.get(CONF_SERIAL)
        or entry.unique_id
        or entry.entry_id
    ).strip()


class IhaHardwareEntity(CoordinatorEntity[IhaHardwareCoordinator]):
    """Base entity for hardware telemetry attached to the IHA device."""

    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: IhaHardwareCoordinator,
        panel_coordinator: IhaCoordinator,
        entry: ConfigEntry,
        unique_suffix: str,
    ) -> None:
        super().__init__(coordinator)
        self.panel_coordinator = panel_coordinator
        self.entry = entry
        self.serial = _panel_serial(panel_coordinator, entry)
        self._attr_unique_id = f"{self.serial}_{unique_suffix}"

    @property
    def available(self) -> bool:
        """Retain the last state during a short local network interruption."""
        return self.coordinator.has_recent_status or super().available

    @property
    def device_info(self) -> DeviceInfo:
        climate = _current_panel_data(self.panel_coordinator)
        data = self.panel_coordinator.data or {}
        return DeviceInfo(
            identifiers={(DOMAIN, self.serial)},
            name=climate.get("name") or data.get("name") or DEFAULT_NAME,
            manufacturer=climate.get("manufacturer") or data.get("manufacturer") or "IHA",
            model=climate.get("model") or data.get("model") or "Wall Thermostat",
            sw_version=(
                climate.get("swVersion")
                or climate.get("sw_version")
                or data.get("swVersion")
                or data.get("sw_version")
            ),
        )

    @property
    def hardware_data(self) -> dict[str, Any]:
        return self.coordinator.data if isinstance(self.coordinator.data, dict) else {}

    @property
    def motion_data(self) -> dict[str, Any]:
        motion = self.hardware_data.get("motion")
        return motion if isinstance(motion, dict) else {}

    @property
    def temperature_data(self) -> dict[str, Any]:
        data = self.hardware_data
        temperature = data.get("temperature") or data.get("localTempSensor")
        return temperature if isinstance(temperature, dict) else {}

    @property
    def hardware_diagnostics(self) -> dict[str, Any]:
        return self.coordinator.connection_diagnostics
