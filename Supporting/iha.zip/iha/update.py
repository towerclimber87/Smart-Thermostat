"""Software update platform for IHA."""

from __future__ import annotations

from typing import Any

from homeassistant.components.update import UpdateEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaUpdateCoordinator
from .entity import IhaCoordinatorEntity, panel_serial


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    parent: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    if parent.update_coordinator is not None:
        async_add_entities([IhaSoftwareUpdate(entry, parent, parent.update_coordinator)])


class IhaSoftwareUpdate(CoordinatorEntity[IhaUpdateCoordinator], UpdateEntity):
    _attr_has_entity_name = True
    _attr_name = "Software"
    _attr_icon = "mdi:monitor-arrow-down-variant"

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaUpdateCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_software"

    @property
    def installed_version(self) -> str | None:
        return self._text("installedVersion")

    @property
    def latest_version(self) -> str | None:
        return self._text("latestVersion") or self.installed_version

    @property
    def in_progress(self) -> bool | int:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        return bool(data.get("inProgress"))

    @property
    def release_summary(self) -> str | None:
        return self._text("message")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        return {
            "phase": data.get("phase"),
            "branch": data.get("branch"),
            "message": data.get("message"),
            "error": data.get("error") or data.get("connectionError"),
        }

    async def async_install(self, version: str | None, backup: bool, **kwargs: Any) -> None:
        await self.coordinator.api.install_update()
        await self.coordinator.async_request_refresh()

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

    def _text(self, key: str) -> str | None:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        value = str(data.get(key) or "").strip()
        return value or None
