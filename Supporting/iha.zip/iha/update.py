"""Software update platform for IHA."""

from __future__ import annotations

import re
from typing import Any

from homeassistant.components.update import UpdateEntity, UpdateEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DEFAULT_NAME, DOMAIN
from .coordinator import IhaCoordinator, IhaUpdateCoordinator
from .entity import _current_panel_data, _panel_serial

PARALLEL_UPDATES = 0


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up the thermostat software update entity."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    update_coordinator = panel_coordinator.update_coordinator
    if update_coordinator is None:
        return
    async_add_entities([IhaSoftwareUpdate(update_coordinator, panel_coordinator, entry)])


class IhaSoftwareUpdate(CoordinatorEntity[IhaUpdateCoordinator], UpdateEntity):
    """Expose the panel's fixed Development-branch updater to Home Assistant."""

    _attr_has_entity_name = True
    _attr_name = "Software"
    _attr_title = "Smart Thermostat Software"
    _attr_icon = "mdi:package-up"
    _attr_supported_features = UpdateEntityFeature.INSTALL

    def __init__(
        self,
        coordinator: IhaUpdateCoordinator,
        panel_coordinator: IhaCoordinator,
        entry: ConfigEntry,
    ) -> None:
        super().__init__(coordinator)
        self.panel_coordinator = panel_coordinator
        self.entry = entry
        self.serial = _panel_serial(panel_coordinator, entry)
        self._attr_unique_id = f"{self.serial}_software_update"

    @property
    def update_data(self) -> dict[str, Any]:
        return self.coordinator.data if isinstance(self.coordinator.data, dict) else {}

    @property
    def panel_data(self) -> dict[str, Any]:
        data = self.panel_coordinator.data or {}
        climate = _current_panel_data(self.panel_coordinator)
        return climate if isinstance(climate, dict) else data

    @property
    def available(self) -> bool:
        # Keep Software usable whenever the thermostat itself is reachable. The
        # update-status coordinator may still be completing its first GitHub
        # check, and the backend briefly restarts during an installation.
        return (
            bool(self.update_data)
            or self.panel_coordinator.has_recent_status
            or bool(self.panel_coordinator.data)
        )

    @property
    def installed_version(self) -> str | None:
        value = (
            self.update_data.get("installedVersion")
            or self.panel_data.get("swVersion")
            or self.panel_data.get("sw_version")
        )
        return str(value).strip() if value not in (None, "") else None

    @property
    def latest_version(self) -> str | None:
        value = self.update_data.get("latestVersion") or self.installed_version
        return str(value).strip() if value not in (None, "") else None

    @property
    def in_progress(self) -> bool:
        return bool(self.update_data.get("inProgress"))

    def version_is_newer(self, latest_version: str, installed_version: str) -> bool:
        """Compare the thermostat's numeric version/date format deterministically."""
        latest = tuple(int(item) for item in re.findall(r"\d+", latest_version)) or (0,)
        installed = tuple(int(item) for item in re.findall(r"\d+", installed_version)) or (0,)
        return latest > installed

    @property
    def release_summary(self) -> str | None:
        if self.update_data.get("updateAvailable"):
            latest = self.latest_version or "the latest version"
            return f"Install {latest} from the thermostat's configured Development branch."
        return None

    @property
    def device_info(self) -> DeviceInfo:
        climate = _current_panel_data(self.panel_coordinator)
        data = self.panel_coordinator.data or {}
        return DeviceInfo(
            identifiers={(DOMAIN, self.serial)},
            name=climate.get("name") or data.get("name") or DEFAULT_NAME,
            manufacturer=climate.get("manufacturer") or data.get("manufacturer") or "IHA",
            model=climate.get("model") or data.get("model") or "Wall Thermostat",
            sw_version=self.installed_version,
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self.update_data
        return {
            "phase": data.get("phase"),
            "message": data.get("message"),
            "branch": data.get("branch"),
            "checked_at": data.get("checkedAt"),
            "check_error": data.get("checkError"),
            "update_error": data.get("error"),
            "update_unit": data.get("unit"),
            "update_log": data.get("log"),
            "connection_error": data.get("connectionError"),
        }

    async def async_install(
        self,
        version: str | None,
        backup: bool,
        **kwargs: Any,
    ) -> None:
        """Start the same safe update action as Fetch Update on the panel."""
        if backup:
            raise HomeAssistantError("Home Assistant backup is not supported by this thermostat updater")
        latest = self.latest_version
        if version and latest and str(version) != str(latest):
            raise HomeAssistantError(
                f"This thermostat can only install the configured Development version {latest}"
            )
        try:
            await self.coordinator.async_start_update()
        except Exception as exc:
            raise HomeAssistantError(f"Could not start the thermostat update: {exc}") from exc
