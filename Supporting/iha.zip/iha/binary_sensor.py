"""Binary sensor platform for IHA hardware."""

from __future__ import annotations

from homeassistant.components.binary_sensor import BinarySensorDeviceClass, BinarySensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import IhaCoordinator, IhaHardwareCoordinator
from .entity import IhaCoordinatorEntity, panel_serial


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    parent: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    if parent.hardware_coordinator is not None:
        async_add_entities([
            IhaMotionSensor(entry, parent, parent.hardware_coordinator),
            IhaScreenLockedSensor(entry, parent, parent.hardware_coordinator),
        ])


class IhaMotionSensor(CoordinatorEntity[IhaHardwareCoordinator], BinarySensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Motion"
    _attr_icon = "mdi:motion-sensor"
    _attr_device_class = BinarySensorDeviceClass.MOTION

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaHardwareCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_motion"

    @property
    def is_on(self) -> bool:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        return bool(motion.get("motion"))

    @property
    def available(self) -> bool:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        return bool(self.coordinator.last_update_success and motion.get("available"))

    @property
    def extra_state_attributes(self):
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        motion = data.get("motion") if isinstance(data.get("motion"), dict) else {}
        return {
            "backend": motion.get("backend"),
            "last_changed_at": motion.get("lastChangedAt"),
            "poll_seconds": (motion.get("config") or {}).get("pollSeconds") if isinstance(motion.get("config"), dict) else None,
        }

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

class IhaScreenLockedSensor(CoordinatorEntity[IhaHardwareCoordinator], BinarySensorEntity):
    """Report whether the physical wall panel currently has its controls locked."""

    _attr_has_entity_name = True
    _attr_name = "Screen Locked"
    _attr_icon = "mdi:lock"
    # Keep this read-only state only as an optional diagnostic. The normal
    # user-facing control is lock.<panel>_screen_lock.
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_entity_registry_enabled_default = False

    def __init__(self, entry: ConfigEntry, parent: IhaCoordinator, coordinator: IhaHardwareCoordinator) -> None:
        super().__init__(coordinator)
        self.entry = entry
        self.parent = parent
        self._serial = panel_serial(entry, parent)
        self._attr_unique_id = f"{self._serial}_screen_locked"

    def _lock_data(self) -> dict:
        data = self.coordinator.data if isinstance(self.coordinator.data, dict) else {}
        value = data.get("screenLock", data.get("screen_lock"))
        return value if isinstance(value, dict) else {}

    @property
    def is_on(self) -> bool:
        return bool(self._lock_data().get("locked"))

    @property
    def available(self) -> bool:
        return bool(self.coordinator.last_update_success and self._lock_data())

    @property
    def extra_state_attributes(self):
        lock = self._lock_data()
        return {
            "lock_mode": lock.get("mode"),
            "security_locked": bool(lock.get("securityLocked", lock.get("security_locked", False))),
            "updated_at": lock.get("updatedAt", lock.get("updated_at")),
        }

    @property
    def device_info(self):
        return IhaCoordinatorEntity(self.entry, self.parent).device_info

