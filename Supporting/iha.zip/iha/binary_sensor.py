"""Binary sensor platform for IHA motion detection."""

from __future__ import annotations

from typing import Any

from homeassistant.components.binary_sensor import BinarySensorDeviceClass, BinarySensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import IhaCoordinator
from .entity import IhaHardwareEntity

PARALLEL_UPDATES = 0


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up the onboard motion entity."""
    panel_coordinator: IhaCoordinator = hass.data[DOMAIN][entry.entry_id]
    hardware_coordinator = panel_coordinator.hardware_coordinator
    if hardware_coordinator is None:
        return
    async_add_entities([IhaMotionSensor(hardware_coordinator, panel_coordinator, entry)])


class IhaMotionSensor(IhaHardwareEntity, BinarySensorEntity):
    """S18-L262B-2 motion output on GPIO27."""

    _attr_name = "Motion"
    _attr_device_class = BinarySensorDeviceClass.MOTION
    _attr_icon = "mdi:motion-sensor"

    def __init__(self, coordinator, panel_coordinator, entry) -> None:
        super().__init__(coordinator, panel_coordinator, entry, "motion")

    @property
    def available(self) -> bool:
        return bool(super().available and self.motion_data.get("available"))

    @property
    def is_on(self) -> bool | None:
        if not self.motion_data:
            return None
        return bool(self.motion_data.get("motion"))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        motion = self.motion_data
        config = motion.get("config") if isinstance(motion.get("config"), dict) else {}
        diagnostics = self.hardware_diagnostics
        return {
            "state_label": motion.get("state"),
            "last_changed_at": motion.get("lastChangedAt"),
            "read_at": motion.get("readAt"),
            "gpio": ((motion.get("pins") or {}).get("rel") or {}).get("gpio")
            if isinstance(motion.get("pins"), dict)
            else None,
            "backend": motion.get("backend"),
            "sensitivity_level": config.get("sensitivityLevel"),
            "check_delay_seconds": config.get("pollSeconds"),
            "sensor_hold_time_seconds": config.get("onTimeSeconds"),
            "telemetry_source": "cached" if diagnostics.get("using_cached_status") else "live",
            "telemetry_last_error": diagnostics.get("last_error"),
        }
